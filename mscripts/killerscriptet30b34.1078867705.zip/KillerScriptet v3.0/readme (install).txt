             -          INTRODUCTION          -        
#########################################################
#                                                       #
# >> KillerScriptet v3.0 for mIRC v6.03 by |Red_Bu||    # 
# >> Version: BETA v3.4                                 #
# >> File: KillerScriptet v3.0 readme                   #
# >> This script is copyrighted � 2001 - 2003           #
# >> All Rights Reserved to Author  (|Red_Bu||          #
#########################################################
# Thank you for downloading and using my script.        #
# This is an all around script, that can be used by     #
# all kind of IRC users.                                #
#                                                       #
# In this script you will find following:               #
# *Away System, *Quit System, *X-Commands,              #
# *Time/Date monitor, *Auto-Voice system, *Fun stuff,   #
# *Weblauncher, *Protections, *PING system,             #
# *Chanserv/Nickserv/Memoserv/operserv                  #
# and alot more usefull IRC stuff.                      #
#                                                       #
# This script has been created to users that are new    #
# to mIRC and to professionals.                         #
# It is recomended that you read this whole help file,  #
# Since it will help you getting started as fast as     #
# possible.                                             #
#                                                       #
# This is a script, which means here are alot of other  #
# features than in the original mIRC script.            #
# This script has mostly been built up by dialogs,      #
# because it is easier to understand them and use them. #
#                                                       #
# I hope you will Enjoy the script, and hopefully you   #
# can start to make your own scripts later.  =)         #
#                                                       #
#                    - |Red_Bu|| -                      #
#########################################################


=<Welcome>=
This script has been made for you to enjoy! This script is not like the very rest,
it is a nice script with new features and nice image. Both for newbies as professionals.
This script has been made for mIRC version 6.03 (Copy a mIRC.exe file to the folder)
It has to be mIRC v6.03! If you don't have one, download mIRC from www.mirc.com (v6.03)


=<Getting started>=
I will now go through the whole getting started option with you in easy steps.

1. Open KillerScriptet v3.0.exe
2. Now a dialog named Personal Settings apear, please take the time to fill out this. (PS: the Toolbar option is not active in this BETA version)
3. In the status window you will get some descriptions about the script.
4. Open the Options dialog, if not opened, and write in nick etc, and connect to a server!

If you still dont get the hang of this, just view the text documents that belongs to mIRC v6.03 in the mIRC Helpfiles folder.


=<Materials>=
All materials in KillerScriptet v3.0 has been scripted/created by |Red_Bu|| I've not used anything I didnt create!
The materials have been made of ideas on some other scripts! But nothing more, I can assure you!
The DLL files included has NOT been made by me, i've downloaded them, and used them so they can improve my script.
And thanks alot for making theese dll files! 


=<Disclaimer>=
1. This script does not contain any trojans or viruses, if you downloaded this script from another site than
   the official website, i would suggest you to run an updated virus program before continue.
2. All programs included with KillerScriptet are used at own risk.
   The author is not responsible for the prolems you have while using this script.
   BUT IF YOU DONT AGREE TO THIS, PLEASE REMOVE THIS SCRIPT NOW!


=<Info>=
Still this script is under BETA versions, which means that if you dont find any bugs/error than i must be 
really good! cause BETA versions are only unfinished versions of a product, so they can slowly become better and better.
So i might say i can garanty you, that you will find bugs/errors and when you do, mail: ole@team-future.com
so i can get started on my misson for a none bug/error script! :)


=<Rippers>=
I'm glad to say that i havent seen any rippers of my products yet! maybe because they aint that good,
but still I'm glad =) and if someone would rip something in this script or any of my products, please be
so kind to leave my name in your script since you got it from me? that would be really nice! or send me 
a mail and ask me! that would be even nicer =) Though, to thoose who just rip some of my stuff:
Any violations to the script's copyrights will be prosecuted by the law!


=<Thanks>=
I would like to thank |Rolf| for alot of help along the way. also a thanks to Kamek for his Theme-Engine.
And of course a thanks to you!


=<Author>=
KillerScriptet v3.0 [BETA v3.4] was created by |Red_Bu||
This script was created to mIRC v6.03

Before i end my speech, i would like to thank |Rolf| for helping me with the smallest problems to the
biggest =) and thank YOU for downloading and using this script!
Please be nice and visit my site everytime you can, and join my channel #BurnOut @ Undernet servers!
Or you can simply join the Team-Future server.. and find usefull information about my script, in the #killerscriptet channel!


Thanks again, and have fun in the IRC WORLD =)


KillerScriptet v3.0  - Brings the chat to YOU! -
============== ====  ===========================


                                     - |Red_Bu|| -

