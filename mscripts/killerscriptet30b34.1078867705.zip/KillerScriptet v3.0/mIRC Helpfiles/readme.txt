 mIRC(R) v6.03 Internet Relay Chat Client
 Copyright (c) 1995-2002 mIRC Co. Ltd.
 All Rights Reserved.

 Welcome to mIRC, an Internet Relay Chat Client.

 mIRC attempts to provide a user-friendly interface for use with
 the Internet Relay Chat network. The IRC network is a virtual
 meeting place where people from all over the world can meet and
 talk.

 To IRC all you need to do is Connect to a server, Join a channel,
 and Chat!

 mIRC will guide you through these initial stages and hopefully
 you'll be chatting in no time. If you get stuck or want to find
 out more about a certain feature, just click on a Help button
 in a window or browse the Help file and you should find many
 hints to help you out.

 As you become more experienced you can also start configuring
 mIRC's features to suit your own needs and tastes, features such
 as colours, fonts, function keys, aliases, popup menus, scripts,
 sounds and many others.

 Remember to visit the mIRC website at http://www.mirc.com for
 the latest version and information.

 Good luck, and have fun.

 Khaled

