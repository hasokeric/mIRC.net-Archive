;------------------------------------------------
There are config files of  Nice Script:

config.hsh
 -change only when on script , configuration of script
hcolors 
 -hash Table for MTS Themes (define html colors)
spchan
 -speacial channel , only change via script
filesico.ini
 -This files you can change path  for script icons but careful
schsound.ini
 -This files you can change sounds for a theme's sound but careful
User.ini : user of script , sexplo.ini : file menu structure  for Special Folder Button
 -Only change via script , because  its structure It's very complex

---------------------------------------------------------------
-DO NOT mODIFY OR DELETE THESE FILES OR YOU WILL ENCOUNTER Many ERRORS-
--------------------------------------------------------------