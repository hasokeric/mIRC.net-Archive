************************************************************************
Maximize to view :)
*************************************************************************
Product Info
------------
Name        : Nice Script (A Script for mIRC)
Version     : 1.8 - 12-6-2005 (dd/mm/yy)
Author      : Niceboy-Dvd 
mail        : dvd21us@yahoo.com
Web         : http://risedvd.tripod.com/ (may change in future)
Requirements: mIRC Version >= 6.03 (It should be the latest version)
	      10 MB hardisk (This is a joke for a computer nowadays)
	      CPU celeron(AMD) 700 MHZ ... (or Higher is recommended)
	      System:Any Windows (Recommend xp)

(This script has tested on windows XP(sp2),2000,98 mIRC 6.03-6.16 with Pentium IV 2.8 GHZ,celeron 1700 MHZ, for slower cpu , script may slow down  your computer)

Readme
-----------

A readme file ? Please double click on NiceScript.chm (File Help of script)
for any information you want to know

Thanks for using Nice Script

Niceboy
July 12,2005
**************************************************************************

A little Note  for THe folder contains This Readme : 
(only for old version  or download at mirc.net or scriptsdb.org)
***
- You can download PackIcons.zip at my site  and then unzip it into mIRC folder. mIRC\PackIcons\
or  NiceScript\PackIcons\  (or $mircdirPackIcons\ ) will contains  some ICL files .and then you can 
use some Toolbar schemes, which I had created . (may be you want to do yourself 
If you don't like them)

- List of Subfolders

+ Low Sensity (fell free to change it)
	-Ascii : some beutiful Text ascii picture files
	-channels:folder for mIRC to run (mIRC)
	-Games : small  exe games 
	-Logs : Log folder (MIRC)
	-Download : download Folder (MIRC)
	-Mp3 (but not mp3\Themes and mp3\BarIcons) : folder if you want store mp3 files
	-MTS_Themes : MTS THemes for script 
(many Themes you can download at www.mircscripts.org and copy in it)	
	-Reports : contains reports 
	-Sounds : sound Folder (mIRC)
	-Clones\Nicebot\Poems : lyrics and poems for Nicebot
(you can copy lyrics or poems in it so that Nicebot take it
and print out channel when use  command ..song <name> or ..poem <name>
This doesn't have in Elite version
)

+ Average Sensity (caution if you want to change it)
	-fdir  : Skin for friends List 
	-fs2002: File Server Folder 
	-helpfile:Some Help File (very useful help)
	-Showit : picture for background function

+ High sensity (couldn't run if miss or changed)
	-Sysfiles: very important folder (main script)
	-Config:The folder contains many settings of Nice script
	-dll: dynamic link library 
	-Image: many dialogs coundn't run if miss it
	-docs: documentary for script (also some text settings)
	-mp3\Themes: some themes for mp3 player
	-mp3\BarIcons: Icon schemes for Music bar
(with mp3\Themes and mp3\Baricons : you could create your themes and copy them into these
folders. so you can  change  Script's GUI follow your favor)
	-clones: some useful bots for script
***
