FileSplit v0.1, first release version
By Scab, script@scab.se


Prerequisites
-------------
mIRC v6.14. It may work with other versions aswell, I just haven't tried.


Installation
------------
1. Extract the script files wherever you want, just keep them in the same folder.
2. Open mIRC.
3. Type in Status: /load -rs x:\path\to\filesplit.mrc
4. You're done.


Usage
-----
The script can be launched through the menubar popup or the /fsplit alias.
It can also be launched from the command line using:

* /fsplit <x:\the.file> <part_size> [b|kb|mb|gb|tb|pb|eb]
* /fmerge <x:\first.file> [number_of_files]

See the source comments for more details. Or just use the dialog... :)


Uninstallation
--------------
1. Open mIRC.
2. Go to the menubar popup and click "FileSplit" -> "Unload".
3. Press Yes in the dialog and you're done.


Practical use
-------------
Example 1: You have three empty floppy disks and a file, my.file, which is 4MB big.
           First open the script and then go to the "Split" tab. Press "Browse"
           and open my.file. Enter 1440000 in the "part size" field (the size of a
           regular floppy disk) and pick "B" in the format drop-down combo. Hit
           "Split" and wait until it's done.

Example 2: You want to store the chunks of a 300MB file on three 128MB USB memory
           sticks. Now, while specifying 128MB as "part size" in the "Split" tab will
           indeed generate 128MB chunks, 128MB disks just can't fit them. Why not?
           Because media manufacturers count 1kB as 1000B while close to all software
           available counts it as 1024B. Thus, a 128MB disk is 1000^2 B big while a
           128MB file is 1024^2 B big. So how do we solve this?

           The calculator. Go to the "Calculator" tab and open the file you wish to
           split there. Enter a "target part size" of 128 MB and hit "Calculate".
           The calculator will suggest a chunk size of 128000000, the exact amount
           of B that a 128MB USB stick can handle (128*(1000^2)). Copy this value
           (double click the line) and enter it as "part size" in the "Split" tab.
           You know the rest from Example 1.

Example 3: We're back at Example 1 with 3 floppy disks that contain one chunk each,
           it's time to merge them. First copy all chunks from the floppy disks to
           the harddrive and make sure they're all in the same folder. Open the script
           and go to the "Merge" tab. Press "Browse" and open my.001 from the folder
           you placed the chunks in. If you can't find, type "*.001" and hit Enter
           and it should show up. Now just hit "Merge" and wait until it's done.

Example 4: This time we simply want to split a big file in two, and thus specify
           the desired number of chunks rather than each chunk size. Again, we need
           the calculator for this. Open the file in the same was as in Example 2,
           but this time enter "2" in the "number of chunks" field and make sure
           that "target part size" is unchecked. Hit "Calculate" and a suitable
           B value will be displayed just as in Example 2.
           

Troubleshooting
---------------
Q: Why are my chunks 16B bigger together than the original file?
A: I use 16B in the first chunk (.001) to store what type of file the source file was.

Q: mIRC freezes while it's splitting!
A: Loops works this way in mIRC. Don't switch to any other program while it's splitting.

Q: Nothing happens when I click a file in the "Recent" popup.
A: You don't have any program associated with the file type. Set one in Windows.


Contact/Feedback/Bug reports
----------------------------
IRC #eXd on irc.quakenet.org or irc.scab.se:6668
E-mail script@scab.se
I'm not on any IM networks.


Scab
2004-06-02