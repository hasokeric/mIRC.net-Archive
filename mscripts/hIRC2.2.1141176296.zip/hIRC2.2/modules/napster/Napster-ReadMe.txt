
;---------
;IMPORTANT:
;---------

When The "Napster Irc" is running, and you made a search, make sure you do not chat with the person who has matches with the search, this is because "Napster Irc" will close the window. It Is advised to either use dcc chat or just download files :D

This addon will only work in channels that use either spr-jukebox or SD-find. :D
 
Your suggestions are greatly appreciated, please email Us At darth^maul@mp3zs.net or Visit us in #mp3zs #malaycable and #hype-script on DALnet. If you want to post this script on your webpage, or use it your script, please inform us. Thanks, Enjoy.


;---------------
;Version History:
;---------------

March 7th, 2003
 1.0 beta - First public release.  

 1.0 - fixed some bugs.
     - can be loaded in directories with spaces.
     - Does not delete search results when viewing other tabs.
     - reduced size. ( 1250 lines to 1171 lines of code )
     
 1.1 - dialog fixes.
     - code clean up
     - strip codes in editbox

 1.2 - dialog fixes.
     - Error checking.

 1.3 - optimized code

 1.4 - optimized code
     - Fixed bug with search.

 1.5 - Removed lisence agreement dialog
     - Removed about dialog
     - Added language patch
     - Updated contact info



;------
;Thanks:
;------

A Special Thanks to selampit. 
To The Creators or Spr-Jukebox and Sd-Find ( you know who you are :P ) for their great file sharing addon. 
And to the users of Napster Irc. Thanks.

Also a special thanks to
 * Khaled Mardam-Bey (khaled@mirc.com) - Created mIRC
 * DragonZap (dragonzap1@aol.com) - Created MDX.dll
 * [CnB]Slinky for his dcc icon i used.
 * http://www.wincustomize.com/  for the XP icons.
 * ReD-LiNe for helping with the mp3 player.
 * iLLu5i0N, Fury_G3, tyso and Tebuan_US for helping me test it.
 
 
 
