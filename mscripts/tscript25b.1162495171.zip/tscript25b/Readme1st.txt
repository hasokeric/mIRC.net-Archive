; tscript 2.5 beta
; released in: 01/11/2006

1� - How to instal
2� - Changes...
3� - Contact
4� - Credits
5� - Versions History

1� - How to instal 

The script is in a ZIPED file.

1�- Unzip tscript.zip to your hard drive,
C:\ for example. You don't need to
create a folder.

2�- Put mIRC.exe in the dir that you
have unziped the file.
If you have unziped the file to C:\tscript
put mIRC.exe in C:\tscript

3�- And now you just need to double click
in mIRC.exe to start using tscript.

* Make sure that you use mIRC6+ *

2� - Changes 

* Modified
+ Added
- Removed
@ To add in next version

* Modified\Changed
+ Added
- Removed
@ To add in next version

* Resize option to the Away Log Dialog
* Resize option to the Systray Log Dialog
* Resize option to the Highlight Mentions Dialog
* Resize option to the DCC's Manager Dialog
* PVTblocker now is on a seperated dialog
* Ballontips is now on a seperated dialog
* About Dialog
* Kicks\Quits reasons
* Add HEXA codes to the Ascii List
* Nicklist popup bug
* Changes on the away system
* Changes on the pvtblocker
* Clones scanner
* Popup menus
* Wizard Initiation dialog
* Help System dialog
* Playlist creator dialog
* Changed all the dialogs titlebars

+ Added tscript <tags> dialog
+ Added dialog to add CTCP TIME\VERSION replys
+ Added ID3 Information dialog
+ Added Playlists Manager dialog
+ Dialog to import nicknames to the notify list
+ Dialog to Kick\Ban a nickname
+ Added Display Editor Dialog
+ Added option to edit the lagbar bars colors
+ Created <mircdir>history\ path to put several script files
+ Added icons on the combo of the "ballontips msg editor" dialog
+ Option to move up\down an item on the toolbar editor

- Control Panel
- nHTML.dll and HTML Helpsystem
- Removed Display section from the mainsetup
- Removed several /alias and other codes that were just a waste of space
- Statusbar has been removed
- Removed several items from the nicklist popup menu

@ Don't know when im going to release a new version
or what kind of changes\updates im going to do.

3� - Contact 

You can contact me by email: tribemx@gmail.com
If you want you can find me in PTnet.

Server: irc.clix.pt:6667 or irc.ptnet.org:6667
Nick: tribe
Channels: #SCT , #ICC , #PTScripting

Server: irc.undernet.org:6667
Nick: tribePT
Channels: #mirc.net

PS:

Please contact only if you have any doubt about the script or
if you need any help related with the script!

4� - Credits

� Morphy, Oje, Snake, [AFX], Kamek, archaeus.
several codes in the remote scripts

� Greeny
I steal his colorpicker idea from NNSCRIPT4 to make mine


� beta testers

diabu
psic0 (picwin lagbar)

And all the #SCT and #PTScripting people!

� Dlls Authors

mdx.dll and all the .mdx extensions - DragonZap
popups.dll - DragonZap
ktools.dll - DragonZap
systray.dll - Narusegawa-Naru
cursor.dll - ooF
fmod.dll - captainEO
edll.dlll - don't know the author nick


� Websites were my script is hosted

www.mircscripts.org
www.scriptsdb.org
www.coderscore.org
www.codedb.org
www.mirc.net
www.ptscripting.com
www.dynamicz.org


� Credits have been given! :)

4� - Versions History (since 2.0) 

* Modified
+ Added
- Removed
! To improve in next version

; TribeScripT v2.0
; Released in: 01/10/2004
= (first public release)

* Main Setup
* Multiserver Suport
* Lag System
* Themes System
* Mp3 Player
* PVT Blocker
* Lag System
* Sidepanel
* Switchbar
* Popups
* Icons
* Sounds dialog
+ Themes System
+ More Servers
+ TitleBar Editor
+ Ballon Tips Configurations


; TribeScripT 2.1
; Released in: 15/11/2004

* 1st time wizard
* DCCS Manager
* Control Panel
* Toolbar
* Some script aliases
* Switchbar

; TribeScripT 2.2
; Released in: 08/12/2004

* DCCS Manager
* Control Panel
* Toolbar
* Some script aliases
* Switchbar
* Main Setup
* Mini Mp3 Player
* Script layout
+ nem display options
+ nem icon set
- Qnx.icl icon pack
- BeOs.icl icon pack


; TribeScripT v2.3
; Released in: 05/01/2005

* 1st time wizard
* Mp3 Player
* Mp3 Options
* Main Setup
* Some dialogs have been changed
+ Channel Protections
+ Private Protections
+ Word Replacer
+ winter.mts theme by greeny
+ Users List
+ Mp3 Player icon Pack

; TribeScript v2.4
; Released in: 04/02/2005

* 1st time wizard
* Main Setup
* Toolbar
* Lots of code has been modified.

+ 5 Icon Packs
+ Toolbar icons size
+ Option to choose between mdx or pw lagbar
+ Network Profiles
+ Mp3 Player Options
+ Lots of code has been added

! Channel Protections
! Pvt Blocker
! Away System

; TribeScript v2.49beta
; Released in: 19/02/2006

* Toolbar
* Sidepanel
* Switchbar
* RGB Viewer (Now Colorpicker)
* First time Wizard
* Script popups
* Nick mentions dialog
* Toolbar editor <tags>
* Improved auto identify system
* Improved auto join system
* Added possibility to change the script fonts
* Tips dialog

+ Fmod.dll
+ Fmod.dll Configuration Dialog
+ Simple Statusbar editor
+ Loading progress bar in the mainsetup

- Users list
- mircwin.dll