script name:	Xchat Clone
version: 	2.7
author:		afterstep@DALnet
email:		slackware74@hotmail.com
last edit:	10/18/04

instructions for newbies or the newbies-at-heart:

extract all files in this archive to c:\

install a version of mirc newer than 6.1 somewhere on the computer, NOT in the XchatClone directory, then copy mirc.exe, and mirc.hlp to C:\XchatClone\


run c:\XchatClone\mirc.exe, and type /setup

that's it.
there is no more.
go away.


credits:
me.
melissa. for putting up with all my geeky shit.
melissa again. because she said so.
Clickhere for the dialog docking dll.
Naru for the nicklist dll.
