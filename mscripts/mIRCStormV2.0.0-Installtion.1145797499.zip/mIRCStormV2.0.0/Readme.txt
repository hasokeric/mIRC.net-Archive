===================================
This is the final release of V2.0.0
===================================

Welcome to the mIRCStorm V2.0.0 readme file.

A : Starting...
B : Documentation
C : More Help?
D : Converting From Beta4 Or Before.

===================================
A: Starting...

   To Start mIRCStorm Simply copy the single mIRC.exe file into the mIRCStorm Folder. The run the mIRC.exe.


B: Documentation

   All Documentation, please see the documentation in the Documentation Folder. Format in either Rich Text Format Or HTML.


D) More Help

   If you are stuck with anything or have any questions more help can be found online at.

   www.mircstorm.co.uk in the forums


E) Converting From Beta4 Or Before

   If you want to keep all your bot settings, included channel and user files you must convert your accounts, otherwise
   the bot will not work correctly. Users, for example, will not be able to login without doing the convert.
   To do this download the convert addon if you do not already have it from www.mircstorm.co.uk. Load the addon
   using the 'Load Addon' in main setup. Then on the bot on any screen type /ConvertAccounts
   You Must have the blowfish.dll file present for the convert to work. You may after the convert remove this file.

=========================================================================================================

Thanks for downloading.

bored? come on:

      IRC.ChatNPlay.net

=========================================================================================================

The author of this script is NOT liable for damages caused by the use, of any kind of this script. 
The author cannot guarantee that this script is free of trojans or viri. By using this script,
you agree to not hold the author responsible for damage caused by the script.

Please respect the author and give credit for ideas and coding that you
may incorperate into your own bot/scripts.

I thought i better put all that :P

So basicly if yours or anyones computer blows up, your country suffers from a heat wave or if a title wave 
hits your house while using or by this script its not my fault.