(((((( Information ))))))
Welcome to -n3rd v1-. We at n3rd decided to make a simple channel bot for channels. We have been working on this project for several months and just recently decided to release it.

(((((( Running ))))))
To run n3rd v1, run:
Simple open mirc.exe

(((((( Configuring ))))))
Click configure on the opening menu. If for some reason, nothing pops up right after you open it, type /menu .
Input all the information, Click Okay and then close the menu.
The bot will minimize and join the server and channel you specified(if things work out right.)
Then, on your client, type .help in the channel or message the bot help. It will give you a list of commands.

((((( Example Configuration )))))
When mirc opens, it should open a menu that says "Credits," "Configure," "Readme," and "Close." I then click Configure and another dialog opens, 
saying "n3rd's NickName," "n3rd's password," "n3rd's owner," "n3rd's Server," "n3rd's E-Mail," and "n3rd's Main Channel."
Here is how I input my information:
n3rd's NickName: n3rd (Simply because it's the name I like.)
n3rd's Password: blahblah (Not my real password, but an example of a potential one.)
n3rd's owner: TeQh (My NickName)
n3rd's Server: Irc.TeQh.Com (My server, but another example of one would be Sterling.VA.US.Undernet.Org)
n3rd's E-Mail: n3rd@TeQh.Com (Yes, my bot has his own email address, but normally this would be your email.)
n3rd's Main Channel: #TeQh (My channel, input your own here though.)

Okay, now that I filled in all that information. I hit Accept. Then, Close. The mIRC then lower's itself and I open up my client and
await n3rd to join the channel I specified on the server I specified. When it joins, I type .help or /msg n3rd help to get a command list.
That's about it.
((((( Upgrading ))))))
To upgrade n3rd v1, visit http://n3rd.teqh.com/ and download the .exe or the .zip and install it over your other bot, then run the mirc.exe and it should be upgraded.

(((((( Features )))))))
n3rd v1 has several features such as:
Supports GameSurge, Undernet, EfNet, and any network using NickServ(ircservices or anope.)
It has several channel management features, such as Op commands, A-Ban commands(Auto ban), and protection for users of n3rd.
It supports three levels of users: owners, ops, and halfops.
It has fun commands such as: .8ball, .cutecmds, and .bar.
It also has utility commands such as: .google.
It has a full help system, to help you with all the commands it has, type .help command name or /msg botname help
It supports public and private commands. To use private commands, simply /msg botname command(without the period.)
More to come.

(((((( Contact ))))))
IRC: Irc.TeQh.Com #Lobby
E-MAIL: AndrewPennington@Gmail.Com
WEBSITE: http://n3rd.teqh.com/
Y!: aowns@yahoo.com
MSN MESSENGER: Game@TeQh.Com