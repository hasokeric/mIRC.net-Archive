~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Introduction
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
This is 4th version of dragon now, still not as good as it can be, more of a file serveing mirc now, thow it can be used to chat as well, alot of changes in new version which can be found on updates text file with download. usage of dlls and hash tbales for first time

thank you for downloading and trying dragon out and i hope all is well with you

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Requirements
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
mirc version : 6.1 or upwards
operating system : windows xp professional (made on this, not tested on others but may work)
harddiskspace: 1.2mb to 2.5mb
resolution: 1024 x 768 ( recommanded ) but not essential, should work on others

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
HOW TO INSTALL
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

to install is very easy,just follow these steps

1) unzip to any folder on your harddrive

2) need a mirc.exe file now on your computer, if you don't have one can
   download mirc 6.16
   http://www.mirc.com

 ( you will also need the help files that come with mirc if you wish for them)

3) once you have a mirc.exe,just move it into the main dragon folder
  or right click on it and copy, then paste into folder

4) should be good to go now

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Contents
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
-away system
-mp3 player
-channel protection
-user protection
-file server
-popups
-picture viewer
-nickserv/memoserv/chanserv/operserv
-system information
-auto joiner 
-fkeys/alias
-mts loader by anaconda
-mts themes
-html help files


~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Contact
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
as any coder will know,much as you try and avoid it,there always 
at least one bug after you first bring something out
any bugs found or questions, can contact me by the following ways


Scotsman78@hotmail.co.uk
If you add this to msn messagner, you will be blocked. This is for email purposes only

PVT MESSAGE AT FOLLOWING SITES

www.mirc.net  nickname: shadowofthenight
www.scriptheaven.net nickname: Shadow
www.hawkee.com nickname: shadowofthenight
www.mircscripts.org  nickname: shadowofthenight
www.team-clanx.org   nickname: shadowofthenight
www.elite-scriptaz.net  nickname: Scotsman


~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Future Plans and Updates
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

I would like to find time to contunie with the dragon project. But due to starting up
my ownn design business and generally being so busy in my life these days. 
I'm unsure if i will be able to but i do have a few further ideas for script. 
These are as follows

1) Code my own theme system

2) Private protection

3) would like to have treeview options on dialogs as picwin treeviews ( Believe this may
   solve small issue with reclicking on something you already clicked on, not setting off 
   respective event, not really that big a issue thow)

4) may add some sort of message system for ctcp replys, quit messages ( they seem popular)

5) may bring back the movie player and internet browser

6) a type of file explorer 

7) would also like to try and offer more than one dialog design choice

8) Would like to combine the html help files into a .chm file at some point to

9) would like to try and find ways to do functions that present .dlls in script do, hense
   i can remove these dlls


These are just thoughts for now , so please don't look for them in future versions
but i shall research these ideas when time away from company allows me to.

Lastly

Thank you for trying Dragon script out and I hope all is well