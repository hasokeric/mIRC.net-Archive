.-----------------------------------.
: UnrealIRCd IRCop v2 commands menu |
'-----------------------------------'

Released: 7, 2004
Type: Snippet
Requirements: mIRC 6.1x
Contents: unrealircop.mrc, readme.txt 
Author: Gizmo967
Home: http://www.mgs3.org
IRC: irc.mgs3.org #Help


I. Instructions:
	unzip countdown into your mirc\ directory then type:
	/load -rs unrealircop.mrc
        and to unload the script:
        /unload -rs unrealircop.mrc
	
II. Command
        Login          - With this you can login as oper and logout too.
        Users and Host - You can change your host/ident/name and users host/ident/name
        Network Control- You can rehash, squit, connect etc
        Abuse control  - The regular kill lines
        Communication  - You can use all global notices here.
        CSop           - With this you can access as oper to OperServ.
        Lines          - All :Lines in IRCd can be accessed here.
        MISC           - /admin /motd /links etc.

III. Comments:
	Feel free to use this script to learn and to expand your ideas. please do not rip.

IV. Credits:
        Paz - This was his idea first
        Sub - For the help

V. Changes:
        v2
         - Full code rewrite
         - Anope IRC Services support
         - Menu will only appear once you /oper
         - MISC added
         - Documentation improved