;----------------------------------------;
;ThanX 1.0.1 by Josh (suonline@gmail.com);
;----------------------------------------;

Thanks to everybody that helped me to create this snippet.

1) Install
Unpack thanx101.zip into your mIRC main directory.
Start your mIRC
Type /load -rs thanx101.mrc

2) Disclaimer
Author (Josh) is not responsable for the damage you might create with this snippet.

3) Author
ThanX by Josh (suonline@gmail.com)
Server: irc.krstarica.com
Port: 6667
Channels: #onlinecm #chari_

;----------------------------------------;
;ThanX 1.0.1 by Josh (suonline@gmail.com);
;----------------------------------------;
