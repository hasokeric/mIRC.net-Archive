My First VB6 mIRC DLL
By MTec89 (mtec89net.com)

Original idea by eminence

steps to create your own DLL in VB 6: docs/mIRCVBDLL.html

example DLL: example.dll

example DLL SRC: example_src/example.vbp

Example DLL Functions: example.dll.functions.txt

example aliases: (in  mfvmd.mrc)

  /vbdll & /vbdll2 take paremeters, and return them back edited.
  /vbdll3 takes paremeters, but throws them away and doesn't use them.