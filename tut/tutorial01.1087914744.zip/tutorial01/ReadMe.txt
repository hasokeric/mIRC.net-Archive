                    	    mIRC Scripting Tutorial
                    	       June 2004 Update
                   	     http//spyderwares.com


	To start the tutorial doubleClick the file named index.htm
	

	For updates visit http://spyderwares.com or subscribe to 
	the SpyderWares mailing list by sending a blank e-mail 
	to spyderwares-subscribe@yahoogroups.com


	What's new:
	1). Many typos fixed.
	2). Many erroneous example codes corrected.
	3). New content added in many chapters.
	4). A few more example codes included.
	5). Scripting Tips updated to 24 points.
        6). Display format greatly improved.



	     Hage Yaapa
	spyderwares@yahoo.com
	     22/06/2004
