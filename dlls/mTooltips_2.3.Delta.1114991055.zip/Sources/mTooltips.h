/*
  Name: mTooltips (Tooltips mIRC DLL)
  Copyright: (c) 2005 EmiZ, el_emiz@yahoo.com.ar
  Author: Emiliano Balbuena (EmiZ)
  Date: 27/12/04
*/

#pragma check_stack(off)
#pragma comment(linker,"/OPT:NOWIN98")

#define WIN32_LEAN_AND_MEAN
#ifndef _WIN32_IE
#define _WIN32_IE 0x0600
#endif

#include <windows.h>
#include <stdlib.h>
#include <ctype.h>
#include <commctrl.h>

#define MIRCMAX         900
#define DLLVER "mTooltips 2.3-DELTA, (c) 2004-2005 EmiZ, el_emiz@yahoo.com.ar"

#define TTMAX           128

#define TTEB_X_ANY_ICO   37
#define TTEB_X_NO_ICO    12
#define TTEB_X_WITH_TXT  12
#define TTEB_Y_OFFSET    17
#define TTEB_W_OFFSET    15
#define TTEB_H_OFFSET     7

// Common Functions

#define mIRCLoad() __declspec(dllexport) void __stdcall LoadDll(LOADINFO* li)
#define mIRCUnload() __declspec(dllexport) int __stdcall UnloadDll(int timeout)
#define mIRC(x) __declspec(dllexport) int __stdcall x(HWND mWnd,HWND aWnd,char *data,char*,BOOL,BOOL)
#define WProc(x) LRESULT CALLBACK x(HWND hwnd,UINT uMsg,WPARAM wParam,LPARAM lParam)
#define Ret(x) { lstrcpy(data,x); lstrcat(data,"\0"); return 3; }
#define RetCmd(x) { lstrcpy(data,x); lstrcat(data,"\0"); return 2; }

#define MIRCSTRING 900

HANDLE hFileMap;
LPSTR mData;
HWND mWnd;
HINSTANCE mInst;

typedef struct {
    DWORD  mVersion;
    HWND   mHwnd;
    BOOL   mKeep;
} LOADINFO;

char* SetCase(const char *szText)
{
 return _strlwr(_strdup(szText));
}

bool IsEqual(const char *szOne, const char *szTwo)
{
  szOne = SetCase(szOne);
  szTwo = SetCase(szTwo);

  if (!strcmp(szOne,szTwo)) return TRUE;

  return FALSE;
}

bool IsFlag(const char *szFlags, char szFlag)
{
    if (szFlags[0] != 0x2B) return FALSE;
    
    int i;
    for (i = 0; i <= strlen(szFlags)-1; i++) {
        if (toupper(szFlags[i]) == toupper(szFlag)) return TRUE;
    }
 
    return FALSE;
}    

void SendCommand(const char* szOne, const char* szTwo = "", const char* szThree = "", const char* szFour = "")
{
	wsprintf(mData,"//%s %s %s %s",szOne,szTwo,szThree,szFour);
	SendMessage(mWnd, WM_USER + 200,0,0);
	return;    
}

char* EvalText(const char* szOne, const char* szTwo = "", const char* szThree = "", const char* szFour = "")
{
	wsprintf(mData,"%s%s%s%s",szOne,szTwo,szThree,szFour);
	SendMessage(mWnd, WM_USER + 201,0,0);
	return mData;    
}



// Tooltip structures

typedef struct tagTOOLTIPS {
  HWND hwndTooltip;
  HWND hwndEditbox;
  bool bIsBalloon;
  bool bHasEditbox;  
  bool bCloseOnClick;
  bool bDontCustomize;
  char szText[600];
  char szHandler[128];
  char szTitle[100];
  TOOLINFO tiStruc;
  HBRUSH hEditBrush;
  WNDPROC wpTooltipProc;
  int iColorEText;
  int iColorEBack;
  int iIcon;
  int iTimerID;
  HFONT hFont;
} TOOLTIPS, *LPTOOLTIPS;

