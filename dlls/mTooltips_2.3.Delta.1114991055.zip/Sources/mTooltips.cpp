/*
  Name: mTooltips (Tooltips mIRC DLL)
  Copyright: (c) 2004-2005 EmiZ, el_emiz@yahoo.com.ar
  Author: Emiliano Balbuena (EmiZ)
*/

#include "mTooltips.h"
#include <shellapi.h>
#include <shlwapi.h>
#include <mmsystem.h>

#define WM_EMIZ 1234
#define PACKVERSION(major,minor) MAKELONG(minor,major)

/* block: global variables */
HWND hwndMain;
TOOLTIPS attTooltips[TTMAX];
int iMaxWidth = 0;

bool bWin2k;
bool bWinXP;
bool bWinSP2;
DWORD dwCCVer;
DWORD dwShVer;

bool bCustomColors = FALSE;
bool bCustomEditbox = FALSE;
int iColorText;
int iColorBack;
int iColorEText;
int iColorEBack;
int iColorEBorder;

char szAllocIcon[257];
int iAllocIconI;
char szCTTFont[32];
int iCTTFontS;

/* tray variables */
bool bTrayInit = FALSE;
NOTIFYICONDATA nidTray;
HICON hTrayIcon;
char szTrayHandler[128];

/* end of block */

/* timer procedure */
VOID CALLBACK lcTimerProc(HWND hwnd,UINT uMsg,UINT_PTR idEvent, DWORD dwTime)
{
  if (!IsWindow(hwnd)) /* if tooltip doesn't exists */
  {
    KillTimer(hwnd,(UINT)idEvent); /* kill this timer */
    return;
  } /* endif */

  int iID = (UINT)idEvent - 1; /* tooltip ID */
  char szID[4]; wsprintf(szID,"%d",iID+1); /* string with ID */
  
  /* block: freeing resources */
  if (attTooltips[iID].iIcon > 3) {
    DestroyIcon((HICON)attTooltips[iID].iIcon);
  }
  attTooltips[iID].iIcon = 0;
  DeleteObject(attTooltips[iID].hFont);
  DeleteObject(attTooltips[iID].hEditBrush);
  DestroyWindow(hwnd);
  KillTimer(hwnd,(UINT)idEvent);
  SendCommand(attTooltips[iID].szHandler,"CLOSE TIMEOUT",szID);
  /* end of block */

  return;
}  

// Window Procedures
WProc(lcTooltipProc)
{
  int iID = (UINT)GetWindowLong(hwnd,GWL_USERDATA);

  switch (uMsg)
  {
    case WM_DESTROY:
    {
      char szID[3];
      wsprintf(szID,"%d",iID+1);

      SendCommand(attTooltips[iID].szHandler,"DESTROY",szID);
      if (attTooltips[iID].iIcon > 3) {
        DestroyIcon((HICON)attTooltips[iID].iIcon);
      }
      attTooltips[iID].iIcon = 0;
      DeleteObject(attTooltips[iID].hFont);
      DeleteObject(attTooltips[iID].hEditBrush);
      break;
    }
    case WM_CTLCOLOREDIT:
    {
      if (attTooltips[iID].bDontCustomize) { break; }
      SetTextColor((HDC)wParam,(COLORREF)attTooltips[iID].iColorEText);
      SetBkColor((HDC)wParam,(COLORREF)attTooltips[iID].iColorEBack);
      return (LONG)attTooltips[iID].hEditBrush;
    }
    case WM_LBUTTONDOWN:
    {
      char szID[3];
      wsprintf(szID,"%d",iID+1);

      if (attTooltips[iID].bCloseOnClick) {
        SendCommand(attTooltips[iID].szHandler,"CLOSE CLICK",szID);
        if (attTooltips[iID].iIcon > 3) {
          DestroyIcon((HICON)attTooltips[iID].iIcon);
        }
        attTooltips[iID].iIcon = 0;
        DeleteObject(attTooltips[iID].hFont);
        DeleteObject(attTooltips[iID].hEditBrush);
        DestroyWindow(hwnd);
        return 0;
      }  
      else
      {
        SendCommand(attTooltips[iID].szHandler,"MOUSE LCLICK",szID);
        break;
      }  
    }  
  }  
  return CallWindowProc(attTooltips[iID].wpTooltipProc,hwnd,uMsg,wParam,lParam);
}  

WProc(lcEditbox)
{
  switch (uMsg)
  {
    case WM_CHAR:
    {
        if ((UINT)wParam != 13) break;
        int iID = (UINT)GetWindowLong(GetParent(hwnd),GWL_USERDATA);
        char szRet[MIRCSTRING];
        char szID[3];
        wsprintf(szID,"%d",iID+1);
        SendMessage(hwnd,WM_GETTEXT,(WPARAM)MIRCSTRING,(LPARAM)(LPCSTR)szRet);
        SendCommand(attTooltips[iID].szHandler,"EDITBOX",szID,szRet);
        if (attTooltips[iID].iIcon > 3) {
          DestroyIcon((HICON)attTooltips[iID].iIcon);
        }
        attTooltips[iID].iIcon = 0;
        DeleteObject(attTooltips[iID].hFont);
        DeleteObject(attTooltips[iID].hEditBrush);
        DestroyWindow(GetParent(hwnd));
        return 0;
    }  
  }  
  return CallWindowProc((WNDPROC)GetWindowLong(hwnd,GWL_USERDATA),hwnd,uMsg,wParam,lParam);
}

WProc(lcMainWindow)
{
  switch(uMsg)
	{
    case WM_EMIZ:
      {
        switch(lParam)
        {
        case WM_LBUTTONDOWN:
          {
            SendCommand(szTrayHandler,"CLICK");
            break;
          }
        case WM_RBUTTONDOWN:
          {
            SendCommand(szTrayHandler,"RCLICK");
            break;
          }
        case WM_LBUTTONDBLCLK:
          {
            SendCommand(szTrayHandler,"DCLICK");
            break;
          }
        case NIN_BALLOONSHOW:
          {
            SendCommand(szTrayHandler,"BALLOON SHOW");
            break;
          }
        case NIN_BALLOONHIDE:
          {
            SendCommand(szTrayHandler,"BALLOON HIDE");
            break;
          }
        case NIN_BALLOONTIMEOUT:
          {
            SendCommand(szTrayHandler,"BALLOON CLOSE");
            break;
          }
        case NIN_BALLOONUSERCLICK:
          {
            SendCommand(szTrayHandler,"BALLOON CLICK");
            break;
          }
        }
        
        break;
      }
    case WM_NOTIFY:
    {
      if ((UINT)wParam != 6666) {
        break;
      }

      LPNMTTDISPINFO lpnmtdi = (LPNMTTDISPINFO) lParam;

      int iID = (UINT)GetWindowLong(lpnmtdi->hdr.hwndFrom,GWL_USERDATA);

      switch (lpnmtdi->hdr.code) {
        case NM_CUSTOMDRAW:
        {
          LPNMTTCUSTOMDRAW lpnmttcd = (LPNMTTCUSTOMDRAW) lParam;

          if (lpnmttcd->nmcd.dwDrawStage == CDDS_POSTPAINT) {
            if ((attTooltips[iID].iIcon > 3) && (!bWinSP2)) {

              RECT rect;
              SendMessage(attTooltips[iID].hwndTooltip,
                TTM_ADJUSTRECT,FALSE,(LPARAM)&rect);
              
              DrawIconEx(lpnmttcd->nmcd.hdc,rect.right-16,rect.bottom+8,
                (HICON)attTooltips[iID].iIcon,16,16,
                0,NULL,DI_NORMAL); /* draw the icon */
            }
            break;
          }

          if (lpnmttcd->nmcd.dwDrawStage == CDDS_PREPAINT) {
            if (!bWinSP2) {
              return CDRF_NOTIFYPOSTPAINT;
            } /* endif */
            break;
          } /* endif */

        }
        case TTN_NEEDTEXT:
        {
          lpnmtdi->lpszText = attTooltips[iID].szText;
          lpnmtdi->hinst = NULL;
          lpnmtdi->uFlags |= TTF_DI_SETITEM;
    
          return 0;
        }
      }  
    }
  }
  return DefWindowProc(hwnd,uMsg,wParam,lParam);
}  
// DLL Functions
void FreeWinResources()
{
  int i;
  
  for (i=0;i<TTMAX;i++)
  {
    if (IsWindow(attTooltips[i].hwndTooltip)) {
      if (attTooltips[i].iIcon > 3) {
        DestroyIcon((HICON)attTooltips[i].iIcon);
      }
      attTooltips[i].iIcon = 0;
      DeleteObject(attTooltips[i].hFont);
      DeleteObject(attTooltips[i].hEditBrush);
      DestroyWindow(attTooltips[i].hwndEditbox);
      DestroyWindow(attTooltips[i].hwndTooltip);
    }
  }
}

// mIRC Functions

// - DLLInfo
mIRC(DLLInfo) {
  Ret(DLLVER);
}

// - GetCompatibility
mIRC(GetCompatibility)
{
  char szRet[900];
  
  if (dwCCVer >= PACKVERSION(5,8)) {
    if (bWinSP2) { lstrcpy(szRet,"OK BALLOONS CUSTOMICON"); }
    else { lstrcpy(szRet,"OK BALLOONS HACK_CUSTOMICON"); }
  }
  else {
    lstrcpy(szRet,"OK NO_BALLOONS HACK_CUSTOMICON");
  } /* endif */

  wsprintf(data,"%s COMCTL32: %d.%d SHELL32: %d.%d",
    szRet,HIWORD(dwCCVer),LOWORD(dwCCVer),
    HIWORD(dwShVer),LOWORD(dwShVer));

  return 3;

}  

// - SetTooltipColors <back-color> <text-color>
// - SetTooltipColors default
mIRC(SetTooltipColors)
{
  char szParam1[9];
  char szParam2[9];
  int iParam1;
  int iParam2;

  if (lstrlen(data) < 1) { Ret("ERR NOT_ENOUGH_PARAMS"); }
  if (IsEqual(data,"default")) {
    bCustomColors = FALSE;
    Ret("OK SET DEFAULT DEFAULT");
  }  

  wsprintf(szParam1,"%s",strtok(data," "));
  wsprintf(szParam2,"%s",strtok(NULL," "));

  if ((lstrlen(szParam1) < 1) || (lstrlen(szParam2) < 1))
   { Ret("ERR NOT_ENOUGH_PARAMS"); }

  iParam1 = (UINT)atoi(szParam1);
  iParam2 = (UINT)atoi(szParam2);

  if ((iParam1 < 0) || (iParam1 > 16777215) ||
     (iParam2 < 0) || (iParam2 > 16777215))
  {
    Ret("ERR OUT_OF_RANGE");
  }  

  iColorBack = iParam1;
  iColorText = iParam2;
  bCustomColors = TRUE;

  wsprintf(data,"OK SET %d %d",iColorBack,iColorText);
  return 3;  
}  

// - SetEditboxColors <back-color> <text-color> <border-style>
// - SetEditboxColors -1 -1 <border-style>
// - SetEditboxColors *
mIRC(SetEditboxColors)
{
  char szParam1[9];
  char szParam2[9];
  char szParam3[2];
  int iParam1;
  int iParam2;
  int iParam3;

  if (lstrlen(data) < 1) { Ret("ERR NOT_ENOUGH_PARAMS"); }
  if (IsEqual(data,"default")) {
    bCustomEditbox = FALSE;
    Ret("OK SET DEFAULT DEFAULT DEFAULT");
  }  

  wsprintf(szParam1,"%s",strtok(data," "));
  wsprintf(szParam2,"%s",strtok(NULL," "));
  wsprintf(szParam3,"%s",strtok(NULL," "));

  if ((lstrlen(szParam1) < 1) || (lstrlen(szParam2) < 1)
    || (lstrlen(szParam3) < 1))
   { Ret("ERR NOT_ENOUGH_PARAMS"); }

  iParam1 = (UINT)atoi(szParam1);
  iParam2 = (UINT)atoi(szParam2);
  iParam3 = (UINT)atoi(szParam3);

  if (iParam1 == -1) { iParam1 = (UINT)GetSysColor(COLOR_INFOBK); }
  if (iParam2 == -1) { iParam2 = (UINT)GetSysColor(COLOR_INFOTEXT); }

  if ((iParam1 < 0) || (iParam1 > 16777215) ||
     (iParam2 < 0) || (iParam2 > 16777215) ||
     (iParam3 < 0) || (iParam3 > 5))
  {
    Ret("ERR OUT_OF_RANGE");
  }  

  iColorEBack = iParam1;
  iColorEText = iParam2;
  iColorEBorder = iParam3;
  bCustomEditbox = TRUE;

  wsprintf(data,"OK SET %d %d %d",iColorEBack,iColorEText,iColorEBorder);
  return 3;  
}  

// - SetTooltipWidth <max-width>
mIRC(SetTooltipWidth)
{
  if (lstrlen(data) < 1) { Ret("ERR NOT_ENOUGH_PARAMS"); }
  int iWidth = atoi(data);
  
  if (iWidth > 1024) { Ret("ERR OUT_OF_RANGE >1024"); }
  if (iWidth < 25) { iWidth = 0; }

  iMaxWidth = iWidth;
  
  wsprintf(data,"OK %d",iWidth);
  return 3;
}

// - SetFont <font name> > <font size>
mIRC(SetFont)
{

  char szFont[32];

  if (lstrlen(data) < 1) {
    Ret("ERR MISSING_PARAMETERS");
  } /* endif */
  
  if (IsEqual(data,"default")) {
    lstrcpy(szCTTFont,"");
    Ret("OK DEFAULT DEFAULT");
  } /* endif */
  
  lstrcpy(szFont,strtok(data,">"));
  StrTrim(szFont," ");
  if (lstrlen(szFont) < 1) {
    Ret("ERR MISSING_PARAMETERS");
  } /* endif */

  lstrcpy(szCTTFont,szFont);

  iCTTFontS = (UINT)atoi(strtok(NULL,""));
  if (iCTTFontS < 1) {
    iCTTFontS = 12;
  }

  wsprintf(data,"OK %d %s",iCTTFontS,szCTTFont);
  return 3;
}

// - CustomIcon <index> <icon file>
mIRC(CustomIcon)
{
  if (lstrlen(data) < 1) { Ret("ERR NOT_ENOUGH_PARAMS"); }
  
  int iIndex = (UINT)atoi(strtok(data," "));
  char szFile[257];
  HICON hIcon;
  
  lstrcpy(szFile,strtok(NULL,""));

  if (iIndex < 1) { iIndex = 0; }
  else { iIndex--; }

  if (lstrlen(szFile) < 1) {
    Ret("ERR NOT_ENOUGH_PARAMS");    
  }

  hIcon = ExtractIcon(mInst,szFile,iIndex);
  if ((UINT)hIcon > 1) {
    lstrcpy(szAllocIcon,szFile);
    iAllocIconI = iIndex;
    DestroyIcon(hIcon);
    wsprintf(data,"OK %d %s",iIndex+1,szFile);
    return 3;
  }
  else {
    wsprintf(data,"ERR CANT_ALLOCATE_ICON %d %s",iIndex+1,szFile);
    return 3;
  }
}
 
// - SetTitle +01234n <id> <title>
//  n=no title change
mIRC(SetTitle)
{
  char szFlags[16];
  int iID;
  char szTitle[100];
  int iIcon = 0;

  if (lstrlen(data) < 1) { Ret("ERR NOT_ENOUGH_PARAMS"); }

  wsprintf(szFlags,"%s",strtok(data," "));
  iID = (UINT)atoi(strtok(NULL," "));
  wsprintf(szTitle,"%s",strtok(NULL,""));

  if (lstrlen(szTitle) < 1) { Ret("ERR NOT_ENOUGH_PARAMS"); }

  if ((iID < 1) || (iID > TTMAX)) { Ret("ERR ID_OUT_OF_RANGE"); }
  iID--;

  if (!IsWindow(attTooltips[iID].hwndTooltip)) { Ret("ERR AVAILABLE_ID"); }
  if (attTooltips[iID].bHasEditbox) { Ret("ERR HAS_EDITBOX"); }

  if (IsFlag(szFlags,'0')) { iIcon = 0; }
  else if (IsFlag(szFlags,'1')) { iIcon = 1; }
  else if (IsFlag(szFlags,'2')) { iIcon = 2; }
  else if (IsFlag(szFlags,'3')) { iIcon = 3; }
  else if (IsFlag(szFlags,'4')) 
  {
    if (attTooltips[iID].iIcon > 3) {
      DestroyIcon((HICON)attTooltips[iID].iIcon);
    }
    if (strlen(szAllocIcon) > 0) {
      iIcon = (UINT)ExtractIcon(mInst,szAllocIcon,iAllocIconI);
    }
    else { iIcon = 0; }
  }
  else {
    iIcon = attTooltips[iID].iIcon;
  }

  attTooltips[iID].iIcon = iIcon;

  if (!IsFlag(szFlags,'n')) {
    if (!lstrcmp(szTitle,"*")) {
      lstrcpy(attTooltips[iID].szTitle,"");
      iIcon = 0;
    }
    else {
      lstrcpy(attTooltips[iID].szTitle,szTitle);
    }
  }

  SendMessage(attTooltips[iID].hwndTooltip, TTM_SETTITLEA,(WPARAM)iIcon, (LPARAM)(LPCSTR)attTooltips[iID].szTitle);
  SendMessage(attTooltips[iID].hwndTooltip, TTM_UPDATE,0,0);

  Ret("OK");
}

// - SetText <id> <text>
//  n=no title change
mIRC(SetText)
{
  int iID;
  char szText[600];

  if (lstrlen(data) < 1) { Ret("ERR NOT_ENOUGH_PARAMS"); }

  iID = (UINT)atoi(strtok(data," "));
  wsprintf(szText,"%s",strtok(NULL,""));

  if (lstrlen(szText) < 1) { Ret("ERR NOT_ENOUGH_PARAMS"); }

  if ((iID < 1) || (iID > TTMAX)) { Ret("ERR ID_OUT_OF_RANGE"); }
  iID--;

  if (!IsWindow(attTooltips[iID].hwndTooltip)) { Ret("ERR AVAILABLE_ID"); }
  if (attTooltips[iID].bHasEditbox) { Ret("ERR HAS_EDITBOX"); }

  lstrcpy(attTooltips[iID].szText,szText);

  SendMessage(attTooltips[iID].hwndTooltip, TTM_UPDATETIPTEXT,0, (LPARAM)&attTooltips[iID].tiStruc);
  SendMessage(attTooltips[iID].hwndTooltip, TTM_UPDATE,0,0);
  
  Ret("OK");
}
  
// - KillTooltip <id>
mIRC(KillTooltip)
{
  if (strlen(data) < 1) { Ret("ERR NOT_ENOUGH_PARAMS"); }

  int iID = (UINT)atoi(data);
  if ((iID < 1) || (iID > TTMAX)) { Ret("ERR ID_OUT_OF_RANGE"); }
  iID--;

  if (!IsWindow(attTooltips[iID].hwndTooltip)) { Ret("ERR AVAILABLE_ID"); }

  if (attTooltips[iID].iIcon > 3) {
    DestroyIcon((HICON)attTooltips[iID].iIcon);
  }
  attTooltips[iID].iIcon = 0;
  DeleteObject(attTooltips[iID].hFont);
  DeleteObject(attTooltips[iID].hEditBrush);
  DestroyWindow(attTooltips[iID].hwndEditbox);
  DestroyWindow(attTooltips[iID].hwndTooltip);
  KillTimer(attTooltips[iID].hwndTooltip,(UINT)attTooltips[iID].iTimerID);
  char szID[3];
  wsprintf(szID,"%d",iID+1);
  SendCommand(attTooltips[iID].szHandler,"CLOSE USER",szID);

  wsprintf(data,"OK %d",iID+1);
  return 3;
}  

// - MoveTooltip id x y
mIRC(MoveTooltip)
{
  if (lstrlen(data) < 1) { Ret("ERR NOT_ENOUGH_PARAMS"); }

  int iID = (UINT)atoi(strtok(data," "));
  int iX = atoi(strtok(NULL," "));
  int iY = atoi(strtok(NULL," "));
  LONG lXY = MAKELONG(iX,iY);
  if ((iID < 1) || (iID > TTMAX)) { Ret("ERR ID_OUT_OF_RANGE"); }
  iID--;

  if (!IsWindow(attTooltips[iID].hwndTooltip)) { Ret("ERR AVAILABLE_ID"); }

  SendMessage(attTooltips[iID].hwndTooltip, TTM_TRACKPOSITION,0,(LPARAM)lXY);

  Ret("OK");
}
  
// - ShowTooltip id +sh
mIRC(ShowTooltip)
{
  if (lstrlen(data) < 1) { Ret("ERR NOT_ENOUGH_PARAMS"); }

  char szFlags[16];
  int iID;
  char szRet[100];

  iID = (UINT)atoi(strtok(data," "));
  wsprintf(szFlags,"%s",strtok(NULL,""));

  /* missing parameters checking */
  if (!lstrlen(szFlags))
  { Ret("ERR MISSING_PARAMETERS"); } /* endif */
  if ((iID < 1) || (iID > TTMAX)) { Ret("ERR ID_OUT_OF_RANGE"); }

  iID--;

  if (!IsWindow(attTooltips[iID].hwndTooltip)) { Ret("ERR AVAILABLE_ID"); }

  if (IsFlag(szFlags,'h')) {
    SendMessage(attTooltips[iID].hwndTooltip, TTM_TRACKACTIVATE,(WPARAM)(BOOL)FALSE,(LPARAM)&attTooltips[iID].tiStruc);
    SendMessage(attTooltips[iID].hwndTooltip, TTM_ACTIVATE,(WPARAM)(BOOL)FALSE,0);
    SendMessage(attTooltips[iID].hwndTooltip, TTM_UPDATE, 0, 0);
  
    wsprintf(szRet,"OK HIDE %d",++iID);
    Ret(szRet);
  }
  else if (IsFlag(szFlags,'s')) {
    SendMessage(attTooltips[iID].hwndTooltip, TTM_ACTIVATE,(WPARAM)(BOOL)TRUE,0);
    SendMessage(attTooltips[iID].hwndTooltip, TTM_TRACKACTIVATE,(WPARAM)(BOOL)TRUE,(LPARAM)&attTooltips[iID].tiStruc);
    SendMessage(attTooltips[iID].hwndTooltip, TTM_UPDATE, 0, 0);

    wsprintf(szRet,"OK SHOW %d",++iID);
    Ret(szRet);
  }

  Ret("ERR NO_FLAGS")
}
// - IsVisible id
mIRC(IsVisible)
{
  if (lstrlen(data) < 1) { Ret("ERR NOT_ENOUGH_PARAMS"); }

  int iID = (UINT)atoi(data);
  if ((iID < 1) || (iID > TTMAX)) { Ret("ERR ID_OUT_OF_RANGE"); }
  iID--;

  if (!IsWindow(attTooltips[iID].hwndTooltip)) { Ret("ERR AVAILABLE_ID"); }

  if (IsWindowVisible(attTooltips[iID].hwndTooltip)) {
    Ret("OK VISIBLE");
  }

  Ret("OK HIDDEN");
}

// - TooltipSize id
mIRC(TooltipSize)
{
  if (lstrlen(data) < 1) { Ret("ERR NOT_ENOUGH_PARAMS"); }

  int iID = (UINT)atoi(data);
  if ((iID < 1) || (iID > TTMAX)) { Ret("ERR ID_OUT_OF_RANGE"); }
  iID--;

  if (!IsWindow(attTooltips[iID].hwndTooltip)) { Ret("ERR AVAILABLE_ID"); }

  char szRet[255];
  long lSize;

  lSize = (LONG)SendMessage(attTooltips[iID].hwndTooltip,TTM_GETBUBBLESIZE,0,(LPARAM)&attTooltips[iID].tiStruc);
  if (!((BOOL)lSize)) { Ret("ERR CANT_GET"); }

  wsprintf(szRet,"OK %d %d",LOWORD(lSize),HIWORD(lSize));

  Ret(szRet);
}

/*
 - SpawnTooltip +flags x y timeout_ms > title $chr(4) text [$chr(4) events handler]
   flags: b = ballon style
          s = don't play balloon associated sound
          0 = old style tooltip
          1 = info icon
          2 = warning icon
          3 = error icon
          4 = custom icon (declared by CustomIcon)
          r = center tip tail
          n = don't animate and don't fade
          a = absolute coordinates specified
          c = don't close on click
          e = attach an editbox
          p = if an editbox attached, make it password box
          f = if an editbox attached, focus editbox
          t = if an editbox attached, show text specified
          d = attach the tooltip to an dialog,
              parameter x is the hwnd, and the y is the ID
          h = attach the tooltip to a hwnd
          q = don't show tooltip
*/

mIRC(SpawnTooltip)
{
  if (lstrlen(data) < 1) { Ret("ERR NOT_ENOUGH_PARAMS"); }

  /* block: parameters variables */
  char szFlags[16];
  int iX;
  int iY;
  int iTimeout;
  char szParams[100];
  char szTitle[100];
  char szText[600];
  char szHandler[128];
  char chr4[2];
  wsprintf(chr4,"%c",4);
  /* end of block */
  
  /* parameters tokenizing and processing */
  wsprintf(szParams,"%s",strtok(data,">"));
  StrTrim(szParams," ");
  if (lstrlen(szFlags) < 1)
    { Ret("ERR MISSING_PARAMETERS"); } /* endif */

  wsprintf(szTitle,"%s",strtok(NULL,chr4));
  StrTrim(szTitle," ");
  if (lstrlen(szTitle) < 1)
    { Ret("ERR MISSING_PARAMETERS"); } /* endif */

  wsprintf(szText,"%s",strtok(NULL,chr4));
  StrTrim(szText," ");
  if (lstrlen(szText) < 1)
    { Ret("ERR MISSING_PARAMETERS"); } /* endif */


  wsprintf(szHandler,"%s",strtok(NULL,""));

  wsprintf(szFlags,"%s",strtok(szParams," "));
  StrTrim(szFlags," ");
  if (lstrlen(szFlags) < 1)
    { Ret("ERR MISSING_PARAMETERS"); } /* endif */

  iX = (UINT)atoi(strtok(NULL," "));
  iY = (UINT)atoi(strtok(NULL," "));
  iTimeout = atoi(strtok(NULL,""));
  /* end of tok and proc <--- LOL! */

  /* NOTE: all of the local variables :D lots!!! *aghhhh* */
  /* block: local variables */
  int i;
  int iID;
  HWND hwndTooltip;
  HWND hwndEditbox;
  HWND hwndControl;
  HWND hwndParent = hwndMain;
  WNDPROC hEditboxProc;
  HFONT hFont;
  RECT rectTooltipSize;
  bool bBalloon = FALSE;
  bool bNoAnim = FALSE;
  bool bEditbox = FALSE;
  bool bEditboxPassw = FALSE;
  bool bEditboxFocus = FALSE;
  bool bShowText = TRUE;
  bool bCloseOnClick = TRUE;
  bool bDontCustomize = TRUE;
  bool bPlaySound = TRUE;
  bool bAttachToID = FALSE;
  bool bAbsolute = FALSE;
  bool bNoShow = FALSE;
  int iIcon = 0;
  int iStyles = WS_POPUP | TTS_NOPREFIX | TTS_ALWAYSTIP;
  int iEditboxStyles = WS_CHILD | WS_VISIBLE | ES_AUTOHSCROLL;
  int iEditboxExStyles = 0;
  int iEditboxX;
  int iEditboxY;
  int iEditboxW;
  int iEditboxH;
  int iEditboxHAdd = 0;
  int iTooltipW;
  int iTooltipH;
  long lXY = MAKELONG(iX,iY);
  /* end of block */

  /* block: processing 'attach to id' and 'attach to hwnd' */
  /* NOTE: too lazy to comment, but it's easy */
  if (IsFlag(szFlags,'d')) {
    bAttachToID = TRUE;
    if (!IsWindow((HWND)iX)) { Ret("ERR INVALID_DIALOG"); }
    iY += 6000;
    hwndControl = GetDlgItem((HWND)iX,iY);
    if (!IsWindow(hwndControl)) { Ret("ERR INVALID_DIALOG_ID"); }
    hwndParent = hwndControl;
    bPlaySound = FALSE;
  }  
  else if (IsFlag(szFlags,'h')) {
    bAttachToID = TRUE;
    if (!IsWindow((HWND)iX)) { Ret("ERR INVALID_HWND"); }
    hwndControl = (HWND)iX;
    hwndParent = hwndControl;
    bPlaySound = FALSE;
  }
  else if ((iX < 0) || (iY < 0) ||
      (iX > 65535) || (iY > 65535)) {
    Ret("ERR BAD_COORDINATES");
  } 
  else {
    if (dwCCVer < PACKVERSION(4,7)) {
      Ret("ERR FLOATING_TOOLTIPS_NOT_SUPPORTED");
    }
  } /* endif */
  /* end of block */
  
  /* Parameters processing */
  
  /* default handler */
  if (lstrlen(szHandler) < 1)
  { lstrcpy(szHandler,".SIGNAL -n mTooltips"); }
  
  /* if can have ballons and I'm on Win2000+ */
  if ((IsFlag(szFlags,'b')) && (dwCCVer >= PACKVERSION(5,80)))
  {
    iStyles |= TTS_BALLOON | TTF_PARSELINKS;
    /* NOTE: WHY LINK PARSING DOESN'T WORK??? */
    bBalloon = TRUE;
  }
  else {
    bPlaySound = FALSE;
  } /* endif */

  /* disable "pop" sound */
  if (IsFlag(szFlags,'s')) { bPlaySound = FALSE; }

  /* absolute positioning */
  if ((IsFlag(szFlags,'a')) && (!bAttachToID)) { bAbsolute = TRUE; }
    
  /* disable window FX */
  if ((!bAttachToID) && (IsFlag(szFlags,'q'))) { 
    bNoShow = TRUE;
    iStyles |=  TTS_NOANIMATE | TTS_NOFADE; 
  }

  /* block: icon flags */
  if (IsFlag(szFlags,'0')) { iIcon = -1; } /* no title/ico */
  else if (IsFlag(szFlags,'1')) { iIcon = 1; } /* info */
  else if (IsFlag(szFlags,'2')) { iIcon = 2; } /* warning */
  else if (IsFlag(szFlags,'3')) { iIcon = 3; } /* error */
  else if (IsFlag(szFlags,'4')) /* custom ico */
  {
    if (lstrlen(szAllocIcon) > 0) {
      iIcon = (UINT)ExtractIcon(mInst,
        szAllocIcon,iAllocIconI); /* extract icon */
    }  
    else { iIcon = 0; } /* endif */
  } /* endif*/
  /* end of block */

  /* if the flag 'e', and not attached to an DID, enable editbox */
  if ((IsFlag(szFlags,'e')) && (!bAttachToID) && (iIcon > -1)) {
    bEditbox = TRUE; /* editbox! */
    bCloseOnClick = FALSE; /* dont close on click */

    if (IsFlag(szFlags,'p')) /* password setting */
    {
      bEditboxPassw = TRUE;
      iEditboxStyles |= ES_PASSWORD;
    } /* endif */

    if (IsFlag(szFlags,'f')) { bEditboxFocus = TRUE; } /* focus */
    if (!IsFlag(szFlags,'t')) { bShowText = FALSE; } /* show text */
  } /* endif */


  /* if specified 'c' flag, disable close on click */
  if (!bEditbox)
  {
    if (IsFlag(szFlags,'c')) {
      bCloseOnClick = FALSE;
    }
  }  

  /* check if there are too many tooltips */
  iID = 0;
  for (i = 0; i < TTMAX; i++)
  {
    if (!IsWindow(attTooltips[i].hwndTooltip)) { break; }
    iID++;
  } /* next */

  if (iID >= TTMAX) /* if there are too many tooltips */
  {
    if (iIcon > 3) {
      DestroyIcon((HICON)iIcon); /* freeing res. */
    } /* endif */

    Ret("ERR TOO_MANY_TOOLTIPS");
  } /* endif */

  hwndTooltip = CreateWindowEx(WS_EX_TOPMOST,
    TOOLTIPS_CLASS, NULL, iStyles, CW_USEDEFAULT, CW_USEDEFAULT,
    CW_USEDEFAULT, CW_USEDEFAULT, hwndParent,
    (HMENU)NULL, NULL, NULL); /* tooltip window creation */

  if (!IsWindow(hwndTooltip)) {
    if (iIcon > 3) { 
      DestroyIcon((HICON)iIcon); /* freeing res. */
    } /* endif */

    Ret("ERR CANT_CREATE_WINDOW");
  } /* endif */

  /* block: font allocation and setting */
  if (lstrlen(szCTTFont) > 0) {
    HDC hDC = GetDC(hwndTooltip);
    int iSize = -MulDiv(iCTTFontS, GetDeviceCaps(hDC, LOGPIXELSY), 72);
    ReleaseDC(hwndTooltip,hDC);
    hFont = CreateFont(iSize,0,0,0,400,FALSE,FALSE,FALSE,
      DEFAULT_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,
      DEFAULT_QUALITY,DEFAULT_PITCH,szCTTFont);

    if (hFont == NULL) {
      hFont = (HFONT)GetStockObject(DEFAULT_GUI_FONT);
    }
  }
  else {
    hFont = (HFONT)GetStockObject(DEFAULT_GUI_FONT);
  } /* endif */

  attTooltips[iID].hFont = hFont;
  
  LOGFONT logFont;
  int ilfSize = GetObject((HGDIOBJ)hFont,sizeof(LOGFONT),NULL);
  GetObject((HGDIOBJ)hFont,ilfSize,&logFont);

  /* end of block */

  SendMessage(hwndTooltip, WM_SETFONT, 
    (WPARAM)hFont, FALSE); /* applying font */

  /*
    (block-of) setting: tooltip hwnd, is balloon or tooltip?, 
    icon (handle or default), close on click?, mIRC handler, 
    parent hwnd, instance and title
  */
  attTooltips[iID].hwndTooltip = hwndTooltip;
  attTooltips[iID].bIsBalloon = bBalloon;
  attTooltips[iID].iIcon = iIcon;
  attTooltips[iID].bCloseOnClick = bCloseOnClick;
  lstrcpy(attTooltips[iID].szHandler,szHandler);

  attTooltips[iID].tiStruc.cbSize = sizeof(TOOLINFO);
  attTooltips[iID].tiStruc.hwnd = hwndParent;
  attTooltips[iID].tiStruc.hinst = NULL;
  lstrcpy(attTooltips[iID].szTitle,szTitle);
  /* end of block */

  /* block: formatting text */
  if (bShowText)
  {
    if (bEditbox) { 
      wsprintf(attTooltips[iID].szText,"%s\r\n\r\n",szText);
    }
    else {
      lstrcpy(attTooltips[iID].szText,szText);
    }
  }
  else { 
      lstrcpy(attTooltips[iID].szText,"\r\n");
  } /* endif */
  /* end of block */

  if (bAttachToID) {
    /* (block-of) setting: text, flags and window ID */
    attTooltips[iID].tiStruc.lpszText = attTooltips[iID].szText;
    attTooltips[iID].tiStruc.uFlags = TTF_TRANSPARENT | TTF_SUBCLASS | TTF_IDISHWND;
    attTooltips[iID].tiStruc.uId = (UINT)hwndParent;
    /* end of block */
  }
  else {
    /* (block-of) setting: text, flags and window ID */
    attTooltips[iID].tiStruc.lpszText = LPSTR_TEXTCALLBACK;
    attTooltips[iID].tiStruc.uFlags = TTF_TRANSPARENT | TTF_TRACK;
    attTooltips[iID].tiStruc.uId = 6666;
    if (bAbsolute) { attTooltips[iID].tiStruc.uFlags |= TTF_ABSOLUTE; }
    /* end of block */
  } /* endif */
  
  if (IsFlag(szFlags,'r')) {
    attTooltips[iID].tiStruc.uFlags = attTooltips[iID].tiStruc.uFlags | TTF_CENTERTIP;
  }
  
  if (!SendMessage(hwndTooltip, TTM_ADDTOOL, 0, (LPARAM)&attTooltips[iID].tiStruc))
  {
    /* block: begin freeing resources */
    DestroyWindow(hwndTooltip);
    if (iIcon > 3) { DestroyIcon((HICON)iIcon); }
    DeleteObject(attTooltips[iID].hFont);
    attTooltips[iID].hwndTooltip = (HWND)0;
    attTooltips[iID].iIcon = 0;
    /* end of block */

    Ret("ERR CANT_CREATE_TOOLTIP");
  }  /* endif */

  SetWindowLong(hwndTooltip,
    GWL_USERDATA,(LONG)iID); /* set the tooltip ID on userdata */

  if (bCustomColors) /* is custom colors are enabled */
  {
    SendMessage(hwndTooltip, TTM_SETTIPBKCOLOR, (WPARAM)(COLORREF)iColorBack, 0);
    SendMessage(hwndTooltip, TTM_SETTIPTEXTCOLOR, (WPARAM)(COLORREF)iColorText, 0);
  } /* endif */

  if (iIcon > -1) /* If an icon was specified, add a title! */
  {
    SendMessage(hwndTooltip, TTM_SETTITLE,(WPARAM)iIcon, (LPARAM)(LPCSTR)szTitle);
  } /* endif */

  /* activate tooltip! */
  if (!bNoShow) SendMessage(hwndTooltip, TTM_ACTIVATE,(WPARAM)(BOOL)TRUE,0);

  if (iMaxWidth > 0) /* if a max width was spec. */
	{
    SendMessage(hwndTooltip, TTM_SETMAXTIPWIDTH, 0, iMaxWidth);
  }	/* endif */

  if (!bAttachToID) {
    /* if is floating, set tracking ON */
    SendMessage(hwndTooltip, TTM_TRACKPOSITION,0,(LPARAM)lXY);
    if (!bNoShow) SendMessage(hwndTooltip, TTM_TRACKACTIVATE,(WPARAM)(BOOL)TRUE,(LPARAM)&attTooltips[iID].tiStruc);
  } /* endif */

  /* block: retrieving tooltip size */
  GetWindowRect(hwndTooltip,&rectTooltipSize);
  iTooltipW = rectTooltipSize.right - rectTooltipSize.left;
  iTooltipH = rectTooltipSize.bottom - rectTooltipSize.top;
  /* end of block */

  /* setting: original window procedure */
  attTooltips[iID].wpTooltipProc = 
    (WNDPROC)SetWindowLong(hwndTooltip,GWL_WNDPROC,
    (LONG)&lcTooltipProc); /* my tooltip window procedure */

  if (bEditbox) /* attach an editbox? */
  {
    /* block: editbox X position */
    if (bShowText) { iEditboxX = TTEB_X_WITH_TXT; }
    else if (iIcon > 0) { iEditboxX = TTEB_X_ANY_ICO; }
    else { iEditboxX = TTEB_X_NO_ICO; }
    /* end of block */

    /* default border: staticedge */
    iEditboxExStyles = WS_EX_STATICEDGE; iEditboxHAdd = 0;

    if (bCustomEditbox) /* shall I customize? */
    {
      /* (block-of) setting: editbox bg brush, text color and bg */
      attTooltips[iID].hEditBrush = CreateSolidBrush((COLORREF)iColorEBack);
      attTooltips[iID].iColorEText = iColorEText;
      attTooltips[iID].iColorEBack = iColorEBack;
      /* end of block */
      
      bDontCustomize = FALSE; /* Customization ENABLED */

      switch (iColorEBorder) /* UD border style */
      {
        case 1: /* single border */
        {
          iEditboxStyles |= WS_BORDER;
          iEditboxExStyles = 0;
          iEditboxHAdd = 0;
          break;
        } /* endcase*/
        case 2: /* dialog frame */
        {
          iEditboxStyles |= WS_DLGFRAME;
          iEditboxExStyles = 0;
          iEditboxHAdd = 4;
          break;
        } /* endcase*/ 
        case 3: /* client edge */
        {
          iEditboxExStyles = WS_EX_CLIENTEDGE;
          iEditboxHAdd = 2;
          break;
        } /* endcase*/
        case 4: /* sunken edge */
        {
          iEditboxStyles |= WS_DLGFRAME;
          iEditboxExStyles = WS_EX_CLIENTEDGE;
          iEditboxHAdd = 6;
          break;
        } /* endcase*/ 
        case 5: /* no border */
        {
          iEditboxHAdd = -2;
          iEditboxExStyles = 0;
          break;
        } /* endcase*/
      } /* endswitch*/

    }  /* endif (custom editbox) */

    /* block: editbox size and pos calculations */
    iEditboxY = iTooltipH + logFont.lfHeight - TTEB_Y_OFFSET - iEditboxHAdd;
    iEditboxW = iTooltipW - iEditboxX - TTEB_W_OFFSET;
    iEditboxH = iEditboxHAdd - logFont.lfHeight + TTEB_H_OFFSET;
    /* end of block */

    hwndEditbox = CreateWindowEx(iEditboxExStyles, "EDIT",
      NULL, iEditboxStyles,
      iEditboxX, iEditboxY, iEditboxW, iEditboxH, hwndTooltip,
      NULL, NULL, NULL); /* editbox window creation */

      if (!IsWindow(hwndEditbox)) {
        /* block: begin freeing resources */
        DestroyWindow(hwndTooltip);
        if (iIcon > 3) { DestroyIcon((HICON)iIcon); }
        DeleteObject(attTooltips[iID].hFont);
        DeleteObject(attTooltips[iID].hEditBrush);
        attTooltips[iID].iIcon = 0;
        attTooltips[iID].hwndTooltip = (HWND)0;
        /* end of block */
  
        Ret("ERR CANT_CREATE_EDITBOX");
      } /* endif */

    /* setting: editbox window */
    attTooltips[iID].hwndEditbox = hwndEditbox; 
    
    SendMessage(hwndEditbox, WM_SETFONT, 
      (WPARAM)hFont, FALSE); /* applying font */

    hEditboxProc = (WNDPROC)SetWindowLong(hwndEditbox,
      GWL_WNDPROC,(LONG)&lcEditbox); /* my editbox procedure */

    SetWindowLong(hwndEditbox,GWL_USERDATA,
      (LONG)hEditboxProc); /* default editbox procedure */
  } /* endif (bEditbox) */

  /* setting: customization value */
  attTooltips[iID].bDontCustomize = bDontCustomize;

  if (bEditboxFocus) { SetFocus(hwndEditbox); } /* focus editbox? */

  if ((!bEditbox) && (!bAttachToID)) /* this is for timeouting */
  {
    if (iTimeout > 1)
    {
      attTooltips[iID].iTimerID = iID + 1;
      SetTimer(hwndTooltip,(UINT)iID + 1,
        iTimeout,(TIMERPROC)&lcTimerProc); /* timeout timer */
    } /* endif */
  } /* endif */

  if (bPlaySound) {
    PlaySound("SystemNotification",
      NULL,SND_ALIAS|SND_NOWAIT|SND_ASYNC); /* "pop" sound */
  } /* endif */

  wsprintf(data,"OK %d",iID+1);
  return 3;
} /* end of function */

// - EnumTooltips
mIRC(EnumTooltips)
{
  int i;

  lstrcpy(data,"OK");
  
  for (i = 0;i < TTMAX;i++)
  {
    if (IsWindow(attTooltips[i].hwndTooltip)) {
      wsprintf(data,"%s %d",data,i+1);
    } /* endif */
  } /* next */

  return 3;
} /* end of function */

/*
    Here goes the GetHWND_* functions
*/

// - GetHWND_DialogID $dialog(dname).hwnd ID
mIRC(GetHWND_DialogID)
{
  int iDialog = (UINT)atoi(strtok(data," "));
  int iID = (UINT)atoi(strtok(NULL," "));
  int iRet;
  
  if (!IsWindow((HWND)iDialog)) {
    Ret("ERR INVALID_DIALOG");
  } /* endif */
  
  if (iID < 1) {
    Ret("ERR INVALID_ID");
  } /* endif */

  iID += 6000;
  
  iRet = (UINT)GetDlgItem((HWND)iDialog,iID);
  if (!iRet) {
    Ret("ERR NO_ID");
  }
  
  wsprintf(data,"OK %d",iRet);
  return 3;  
}

// - GetHWND_WinStatic $window(@name).hwnd
mIRC(GetHWND_WinStatic)
{
  int iWin = (UINT)atoi(data);
  int iRet;
  
  if (!IsWindow((HWND)iWin)) {
    Ret("ERR INVALID_WINDOW");
  } /* endif */
  
  iRet = (UINT)FindWindowEx((HWND)iWin,NULL,"Static",NULL);

  if (iRet < 1) {
    Ret("ERR WINDOW_HASNT_STATIC");
  } /* endif */
  
  wsprintf(data,"OK %d",iRet);
  return 3;  
}

// - GetHWND_WinEdit $window(@name).hwnd
mIRC(GetHWND_WinEdit)
{
  int iWin = (UINT)atoi(data);
  int iRet;
  
  if (!IsWindow((HWND)iWin)) {
    Ret("ERR INVALID_WINDOW");
  } /* endif */
  
  iRet = (UINT)FindWindowEx((HWND)iWin,NULL,"RichEdit20A",NULL);

  if (iRet < 1) {
    iRet = (UINT)FindWindowEx((HWND)iWin,NULL,"Edit",NULL);

    if (iRet < 1) {
      Ret("ERR WINDOW_HASNT_EDIT");
    } /* endif */
  } /* endif */
  
  wsprintf(data,"OK %d",iRet);
  return 3;
}

// - GetHWND_WinList $window(@name).hwnd
mIRC(GetHWND_WinList)
{
  int iWin = (UINT)atoi(data);
  int iRet;
  
  if (!IsWindow((HWND)iWin)) {
    Ret("ERR INVALID_WINDOW");
  } /* endif */
  
  iRet = (UINT)FindWindowEx((HWND)iWin,NULL,"Listbox",NULL);

  if (iRet < 1) {
    Ret("ERR WINDOW_HASNT_LIST");
  } /* endif */
  
  wsprintf(data,"OK %d",iRet);
  return 3;
}

// - GetHWND_Rect hwnd
mIRC(GetHWND_Rect)
{
  int iWin = (UINT)atoi(data);
  RECT rect;
  
  if (!IsWindow((HWND)iWin)) {
    Ret("ERR INVALID_WINDOW");
  } /* endif */
  
  GetWindowRect((HWND)iWin,&rect);
 
  wsprintf(data,"OK %d %d %d %d",rect.left,rect.top,rect.right,rect.bottom);
  return 3;
}

/*
    End of the GetHWND_* functions
*/

/*
    BEGIN OF TRAYICON STUFF
*/

// - Balloon +flags title $chr(4) text
mIRC(Balloon)
{
  if (!bTrayInit) {
    Ret("ERR NOT_INITIALIZED");
  } /* endif */

  if (lstrlen(data) < 1) {
    Ret("ERR MISSING_PARAMETERS");
  } /* endif */

  char szFlags[16];
  char szTitle[63];
  char szText[255];
  char chr4[2];
  wsprintf(chr4,"%c",4);

  wsprintf(szFlags,"%s",strtok(data," "));
  wsprintf(szTitle,"%s",strtok(NULL,chr4));
  wsprintf(szText,"%s",strtok(NULL,""));

  StrTrim(szTitle," ");
  StrTrim(szText," ");

  /* missing parameters checking */
  if ((!lstrlen(szFlags)) ||
      (!lstrlen(szTitle)) ||
      (!lstrlen(szText)))
  { Ret("ERR MISSING_PARAMETERS"); } /* endif */

  int iIcon = 0;
  int iNoSound = 0;

  /* block: icon flags */
  if (IsFlag(szFlags,'0')) { iIcon = NIIF_NONE; } /* no title/ico */
  else if (IsFlag(szFlags,'1')) { iIcon = NIIF_INFO; } /* info */
  else if (IsFlag(szFlags,'2')) { iIcon = NIIF_WARNING; } /* warning */
  else if (IsFlag(szFlags,'3')) { iIcon = NIIF_ERROR; } /* error */
  else { iIcon = 0; } /* endif */
  /* end of block */

  if (IsFlag(szFlags,'n')) { iNoSound = NIIF_NOSOUND; } /* no sound */

  nidTray.dwInfoFlags = iIcon | iNoSound;
  lstrcpy(nidTray.szInfoTitle,szTitle);
  lstrcpy(nidTray.szInfo,szText);
  Shell_NotifyIcon(NIM_MODIFY, &nidTray);
  
  Ret("OK")
}

// - TrayInit index icon.ico > mirc handler > tip text
mIRC(TrayInit)
{
  if (bTrayInit) {
    Ret("ERR ALREADY_INITIALIZED");
  } /* endif */


  if (lstrlen(data) < 1) {
    Ret("ERR MISSING_PARAMETERS");
  } /* endif */
  
  char szFile[256];
  char szHandler[128];
  int iIndex;

  /* block: maximum tooltip len */
  char szTipTextA[64];
  char szTipTextB[128];

  /* block: parameters tokenizing and stripping */
  iIndex = (UINT)atoi(strtok(data," "));
  lstrcpy(szFile,strtok(NULL,">"));
  lstrcpy(szHandler,strtok(NULL,">"));
  if (dwShVer >= PACKVERSION(5,0)) {
    lstrcpy(szTipTextB,strtok(NULL,""));
    StrTrim(szTipTextB," ");

    if (lstrlen(szTipTextB) < 1) {
      Ret("ERR MISSING_PARAMETERS");
    } /* endif */
  }
  else {
    lstrcpy(szTipTextA,strtok(NULL,""));
    StrTrim(szTipTextA," ");

    if (lstrlen(szTipTextA) < 1) {
      Ret("ERR MISSING_PARAMETERS");
    } /* endif */
  }

  StrTrim(szFile," ");
  StrTrim(szHandler," ");
  /* end of block */

  /* block: parameters checking */

  if (lstrlen(szFile) < 1) {
    Ret("ERR MISSING_PARAMETERS");
  } /* endif */
  
  if (lstrlen(szHandler) < 1) {
    lstrcpy(szHandler,".SIGNAL -n mTooltips_Tray");
  } /* endif */

  if (iIndex < 1) {
    iIndex = 1;
  } /* endif */

  hTrayIcon = ExtractIcon(mInst,szFile,iIndex-1);
  if ((UINT)hTrayIcon < 2) {
    wsprintf(data,"ERR CANT_ALLOCATE_ICON %d %s",iIndex+1,szFile);
    return 3;
  }

  /* end of block */
  
  nidTray.hWnd = hwndMain;
  nidTray.hIcon = hTrayIcon;
  if (dwShVer >= PACKVERSION(5,0)) {
    lstrcpy(nidTray.szTip,szTipTextB);
  }
  else {
    lstrcpy(nidTray.szTip,szTipTextA);
  }

  if (dwShVer >= PACKVERSION(5,0)) {
    nidTray.uFlags = NIF_ICON | NIF_TIP | NIF_INFO | NIF_MESSAGE;
    nidTray.uVersion = NOTIFYICON_VERSION;
    nidTray.dwInfoFlags = NIIF_NONE;
  }  
  else {
    nidTray.uFlags = NIF_ICON | NIF_TIP | NIF_MESSAGE;
  }
  
  nidTray.uCallbackMessage = WM_EMIZ;
  
  lstrcpy(szTrayHandler,szHandler);

  Shell_NotifyIcon(NIM_ADD,&nidTray);
  if (dwShVer >= PACKVERSION(5,0)) {
    Shell_NotifyIcon(NIM_SETVERSION,&nidTray);
  }

  bTrayInit = TRUE;
  
  Ret("OK");
}

/*
    END OF TRAYICON STUFF
*/

/* get comm ctrl version */
DWORD GetLVer(const char* szDLL)
{
  HINSTANCE hinstDll;
  DWORD dwVersion = 0;
  
  hinstDll = LoadLibrary(szDLL);
  
  if (!hinstDll) {
    return dwVersion;
  } /* endif */

  DLLGETVERSIONPROC pDllGetVersion;
  pDllGetVersion = (DLLGETVERSIONPROC)GetProcAddress(hinstDll, 
    "DllGetVersion");

  if(!pDllGetVersion) {
    FreeLibrary(hinstDll);
    return dwVersion;
  } /* endif */

  DLLVERSIONINFO dvi;
  HRESULT hr;
  
  ZeroMemory(&dvi, sizeof(dvi));
  dvi.cbSize = sizeof(dvi);
  
  hr = (*pDllGetVersion)(&dvi);
  
  if(SUCCEEDED(hr)) {
    dwVersion = PACKVERSION(dvi.dwMajorVersion, dvi.dwMinorVersion);
  } /* endif */

  FreeLibrary(hinstDll);
  return dwVersion;
} /* end of function */

/* my tooltip window */
void RegMyTTWindow()
{
  WNDCLASSEX wcex; /* window class structure */
  
  ZeroMemory(&wcex,sizeof(WNDCLASSEX)); /* initialize */
  wcex.cbSize = sizeof(WNDCLASSEX);
  
  wcex.style = 0; /* no style */
  wcex.lpfnWndProc = &lcMainWindow; /* window proc*/
  wcex.hInstance = mInst; /* mirc instance */
  wcex.lpszClassName = "mTooltips_Main"; /* class name */
  
  RegisterClassEx(&wcex); /* register, long live to MS */
  
  hwndMain = CreateWindow("mTooltips_Main", "mTooltips",WS_CAPTION,0,0,10,10,mWnd,
    NULL,NULL,NULL); /* create the window :D */
  
} /* end of function */

/* dll loading */
mIRCLoad()
{
  mWnd = li->mHwnd; /* main mirc window */
  mInst = (HINSTANCE)GetWindowLong(mWnd,
    GWL_HINSTANCE); /* get mirc instance */
  hFileMap = CreateFileMapping(INVALID_HANDLE_VALUE,0,
    PAGE_READWRITE,0,4096,"mIRC"); /* file map for cmd and eval */
  mData = (LPSTR)MapViewOfFile(hFileMap,
    FILE_MAP_ALL_ACCESS,0,0,0); /* view-of-filemap */

  /* block: init common controls */
  INITCOMMONCONTROLSEX iccs;
  iccs.dwSize = sizeof(iccs);
  iccs.dwICC = ICC_WIN95_CLASSES;

  InitCommonControlsEx(&iccs);
  /* end of block */

  /* get comctl32 version */
  dwCCVer = GetLVer("Comctl32.dll");
  dwShVer = GetLVer("Shell32.dll");

  /* block: check MSWin version, for special stuff (2k, XP, XP-SP2) */
  OSVERSIONINFO osvi;
  osvi.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
  GetVersionEx(&osvi);
  bWin2k = (osvi.dwMajorVersion >= 5);

  if (((osvi.dwMajorVersion == 5) && (osvi.dwMinorVersion == 1)) ||
    (osvi.dwMajorVersion > 5)) {
    bWinXP = TRUE;
    OSVERSIONINFOEX osviex;
    osviex.dwOSVersionInfoSize = sizeof(OSVERSIONINFOEX);
    GetVersionEx((OSVERSIONINFO *)&osviex);

    if ((osvi.dwMajorVersion == 5) && (osvi.dwMinorVersion == 1)) {
      bWinSP2 = (osviex.wServicePackMajor >= 2);
    }
    else {
      bWinSP2 = TRUE;
    } /* endif */

  } /* endif */
  else { 
    bWinXP = FALSE;
    bWinSP2 = FALSE;
  } /* endif */
  /* end of block*/

  RegMyTTWindow(); /* create my window */

  /* block: notifyicondata initializing */
  if (dwShVer >= PACKVERSION(5,0)) {
    nidTray.cbSize = sizeof(NOTIFYICONDATA);
  }
  else {
    nidTray.cbSize = NOTIFYICONDATA_V2_SIZE;
  }
  nidTray.hWnd = hwndMain;
  nidTray.uID = 6666;
  /* end of block */

  li->mKeep = TRUE; /* dll must be kept in memory */
} /* end of function */

/* dll unloading */
mIRCUnload()
{
  if (!timeout) /* if not timeout'd */
  {
    /* block: free notifyicon */
    if (bTrayInit) {
      Shell_NotifyIcon(NIM_DELETE,&nidTray);
      DestroyIcon(hTrayIcon);
    }
    /* end of block */

    /* block: freeing resources */
    FreeWinResources();
    DestroyWindow(hwndMain);
    UnregisterClass("mTooltips_Main",mInst);
    UnmapViewOfFile(mData);
    CloseHandle(hFileMap);
    /* end of block */
    return 1;
  } /* endif */

  return 0;
} /* end of function */

/*
    END OF MY UGLY TOOLTIPS DLL
    
    THANKS FOR WATCHING
    TUNE US NEXT WEEK
    WITH "LIZARD INVADERS FROM THE MOON"
    IN RETRO CHANNEL...
*/
