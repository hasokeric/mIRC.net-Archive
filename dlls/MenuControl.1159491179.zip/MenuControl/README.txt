-------------------------------------
	MenuControl 1.0
	  by Haso K	(Osah)
_____________________________________

Functions & Examples:

	Function: about
	Example: //echo -s $dll(MenuControl.dll,about,)

	Function: control
	Parameters: $DLL(MENUCONTROL.DLL,control,<Title of Window>:<Clicks>:<MenuItem>:<SubMenuItem>:<SubMenuItem2>)
	Example: //echo -s $dll(MenuControl.dll,control,mIRC:2:1:1)

	Explanation:
	
	<Title of Window>
	Here you supply the Title of the window you wish to control the Menu
	Example:  mIRC would be for mIRc		MSN Messenger would be for MSN

	<Clicks>
	Here you supply how many SubMenus you wish to click on (1 is min, 3 is max)

	<MenuItem>
	Here you supply the First Item on the menu
	mIRC Example:  0 = File, 1 = View, 2 = Favorites ....
	Remember: You Always start from 0. Not From 1.
	Now if on <Clicks> you supplied 1 it would execute this item, but you cannot execute in mIRC
	File because it has submenus so you would use on Clicks 2.

	<SubMenuItem>
	Here you supply the SubMenu
	Example: //echo -a $dll(MenuControl.dll,control,mIRC:2:1:2) = View > Toolbar (Would hide/or show toolbar)

	<SubMenuItem2>
	Here you can supply second SubMenu
	Example: //echo -a $dll(MenuControl.dll,control,mIRC:3:0:0:0) = File > Recent Servers > New Server Window

	I know my explanations are not good. So here are some examples. Remember just play around in 5 minutes you
	shall master this dll.


	Examples:

	MSN 7.0
	//echo -a $dll(MenuControl.dll,control,MSN Messenger:3:0:4:1) = Sets status to Busy.
	Because it does File > My Status > Busy(And executes this one) because can you see :3:
	It tells it which item to actually Execute.

	mIRC
	//echo -a $dll(MenuControl.dll,control,mIRC:2:6:1) = Help > Search...

	mIRC (Hide/Show Treebar)
	//echo -a $dll(MenuControl.dll,control,mIRC:2:1:3)


	