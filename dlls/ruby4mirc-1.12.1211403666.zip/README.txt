RELEASE INFORMATION

	- Ruby4mIRC version 1.12 released May 21st 2008.
		> Updated CLB for mIRC 6.32

	- Ruby4mIRC version 1.11 released November 9th 2007.
		> Fixed bug that kept the Ruby runtime dll loaded when
		  other Ruby dll/so libraries were required. The dll
		  should now be properly unloaded when called with 
		  /rbunload.
		
	- Ruby4mIRC version 1.1 released November 1st 2007.
		> Various minor bugfixes
		> Changed the way ruby4mirc parses embedded scripts.
		> Added mirc[:varname] accessor method to get/set variables.
		
	- Ruby4mIRC version 1.01 released August 28th 2007.
		> Initial release.

AUTHOR & WEBSITE
	
	The software provided was written by Loren Segal, clb@soen.ca

	Please visit http://www.kthx.net/clb/ruby4mirc for updates.

DESCRIPTION

	Ruby4mIRC is a DLL for the mIRC chat client (http://www.mirc.com)
	that gives a scripter the ability to load Ruby code as well as 
	embed it directly into mIRC script files. For information on
	how to use this DLL, see the USING section below.
	
INSTALLATION

	!! IMPORTANT !! 
		This release is currently compatible *ONLY* with mIRC 6.3+. Please
		make sure you are running this version before trying to use this
		DLL. While the DLL may remain semi-functional in previous versions,
		you will lack much of the functionality that makes this DLL 
		worthwhile.


	To install this script and DLL, it is recommended (but not necessary)
	to copy the files in this package into a directory within mIRC's 
	installation directory. At that point you can type
	
		/load -rs C:\path\to\ruby.mrc
		
	To load the script file. This will run /testrb to test the installation
	of the Ruby4mIRC DLL. You should see "Ruby works great!" if the test
	ran successfully.
	
	While Ruby is not necessary to run this DLL**, it is recommended that 
	you install it and verify that you have Ruby installed in your %PATH% 
	to take full advantage of the language's standard library functionality.
	If Ruby is not found in your path, mIRC should generate a warning.
	
	** Note: If you do not have Ruby installed you must first copy the 
			 Ruby core library `msvcrt-ruby18.dll` from the support 
			 directory in this package into the **MIRC DIRECTORY**. 
			 
			 I REPEAT, THE FILE `msvcrt-ruby18.dll` MUST BE COPIED INTO
			 THE MIRC DIRECTORY, NOT THE SCRIPT SUB-DIRECTORY, FOR THIS 
			 DLL TO WORK IF YOU DO NOT HAVE RUBY INSTALLED.
	
USAGE & EXAMPLES

	Ruby4mIRC comes with a tiny implementation of IRB, you can type /irb
	to get an interactive Ruby console.

	Because the rest of the documentation is too long to include here, please
	see USAGE.txt for extended information on how to use Ruby4mIRC.
	
	Examples are also included directly in ruby.mrc. The main methods
	you'll need are mirc(command), mirc.identifier and mirc[:variable]
	
LICENSE
	
	Ruby4mIRC is released under a BSD-style license. The only thing that I ask
	is that you share any modifications to the source with me if you plan on 
	redistributing in binary form. See LICENSE.txt for more information.
	
	Not all of the source code of this DLL can be released for legal reasons.
	As of version 1.1 the closed source portion of the code has been moved to 
	the Common Language Bridge module (CLB) and is released as a static compiled 
	library only. The library will eventually be released under the same BSD-
	style license when I figure out a proper way to distribute the closed source 
	element of the code. The code can be fully compiled using this static library.
	
	Note: The file `msvcrt-ruby18.dll` is not written by me and therefore
	does not fall under the above license. To see Ruby's license, please visit
	http://www.ruby-lang.org/en/LICENSE.txt
	
TRADEMARK NOTICE
	
	mIRC is a registered trademark of mIRC Co. Ltd. 