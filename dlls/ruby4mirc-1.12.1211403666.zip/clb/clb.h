#ifndef HAVE_CLB /* HAVE_CLB */
#define HAVE_CLB

#include "mirc.h"

#define CLB_SIGNAL_PREFIX "/.signal -n "
#define CLB_HALT(data)    { strcpy(data, "/halt"); return 2; }

/* Initialization and shutdown */
BOOL  CLBStartup(LOADINFO *loadinfo, const char *signalPrefix);
BOOL  CLBInitialize(char **data);
void  CLBShutdown(void);
BOOL  CLBDirectMessaging(void);
char *CLBGetLoadPath(const char *command);

/* Sending a command to mIRC */
#define CLB_MNULL		0
#define CLB_MFALSE		1
#define CLB_MTRUE		2
#define CLB_MINTEGER	3
#define CLB_MFLOAT		4
#define CLB_MSTRING		5

char   *CLBExecute(const char *command, int evalTimes, int type);
char   *CLBExecutef(const char *fmt, int evalTimes, int type, ...);
int		CLBResultType(const char *result);

#define CLB_DEFAULT_EVALTIMES 2
#define CLBCommandOrEvaluate(data) (*data == '$' || *data == '%' ? WM_MEVALUATE : WM_MCOMMAND)

/* Extra helper versions of the CLBExecute/f function */
#define CLBExecute2(command, evalTimes)		CLBExecute(command, evalTimes, CLBCommandOrEvaluate(command))
#define CLBExecute2f(fmt, evalTimes, ...)	CLBExecutef(fmt, evalTimes, CLBCommandOrEvaluate(data), __VA_ARGS__)
#define CLBExecute3(command)				CLBExecute(command, CLB_DEFAULT_EVALTIMES, CLBCommandOrEvaluate(command))
#define CLBExecute3f(fmt, ...)				CLBExecutef(fmt, CLB_DEFAULT_EVALTIMES, CLBCommandOrEvaluate(data), __VA_ARGS__)

#define CLBEvaluate(data, evalTimes)		CLBExecute(data, evalTimes, WM_MEVALUATE)
#define CLBEvaluate2(data)					CLBExecute(data, CLB_DEFAULT_EVALTIMES, WM_MEVALUATE)
#define CLBEvaluatef(fmt, evalTimes, ...)	CLBExecutef(fmt, evalTimes, WM_MEVALUATE, args)
#define CLBEvaluate2f(fmt, ...)				CLBExecutef(fmt, CLB_DEFAULT_EVALTIMES, WM_MEVALUATE, __VA_ARGS__)

#define CLBCommand(command, evalTimes)		CLBExecute(command, evalTimes, WM_MCOMMAND)
#define CLBCommand2(command)				CLBExecute(command, CLB_DEFAULT_EVALTIMES, WM_MCOMMAND)
#define CLBCommandf(fmt, evalTimes, ...)	CLBExecutef(fmt, evalTimes, WM_MCOMMAND, __VA_ARGS__)
#define CLBCommand2f(fmt, ...)				CLBExecutef(fmt, CLB_DEFAULT_EVALTIMES, WM_MCOMMAND, __VA_ARGS__)

#endif /* HAVE_CLB */