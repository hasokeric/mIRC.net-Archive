#ifndef HAVE_MIRC /* HAVE_MIRC */
#define HAVE_MIRC

#include <windows.h>

#define MIRC_MAXSTRING	4096
#define WM_MCOMMAND	    (WM_USER+200)
#define WM_MEVALUATE	(WM_USER+201)

#define MIRC_TRUE	"$true"
#define MIRC_FALSE	"$false"
#define MIRC_NULL	""

typedef struct {
	short major;
	short minor;
} MVERSION;

typedef struct {
	MVERSION mVersion;
	HWND   mHwnd;
	BOOL   mKeep;
} LOADINFO;

#endif /* HAVE_MIRC */