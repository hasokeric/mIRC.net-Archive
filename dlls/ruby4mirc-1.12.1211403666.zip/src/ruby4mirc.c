#include "ruby4mirc.h"

/* Initialization function prototypes */
static void get_ruby_load_path();
static void rb_initialize();
static void get_ruby_load_path();
static VALUE rb_repr_inum_convert(VALUE result);

VALUE RUBYDLL_VERSION, SUPPORTED;

VALUE m_eval(int argc, VALUE *argv, VALUE self) {
	VALUE data, eval;
	int neval = CLB_DEFAULT_EVALTIMES;

	if (argc == 0) {
		return rb_mMIRC;
	}
	else {
		rb_scan_args(argc, argv, "11", &data, &eval);

		Check_Type(data, T_STRING);

		if (RTEST(eval)) {
			Check_Type(eval, T_FIXNUM);
			neval = FIX2INT(eval);
		}

		return rb_repr(CLBCommand(StringValueCStr(data), neval));
	}
}

/* Safety call functions */

VALUE rb_safe(VALUE (*func)(void *), void *value) {
    int status = 0;
    VALUE result = rb_protect((VALUE (*)(VALUE))func, (VALUE)value, &status);
    if (status != 0) { /* Raise formatted exception (ErrClass: message) */
		VALUE err_obj = rb_gv_get("$!");
		VALUE err_str = rb_str_new2("");
		rb_str_append(err_str, rb_obj_as_string(rb_obj_class(err_obj)));
		rb_str_append(err_str, rb_str_new2(": "));
		rb_str_append(err_str, rb_gv_get("$!"));
        rb_funcall(rb_stderr, rb_intern("puts"), 1, err_str);
        rb_backtrace();
		return -1;
    }
    return result;
}

VALUE rb_arbitrary_funcall(char *data) {
    /* Split into command and parameters */
    char *params = strstr(data, " ");
    if (params == NULL || params + 1 == data + strlen(data)) {
        rb_raise(rb_eArgError, "invalid arguments");
        return Qnil;
    }
    *(params++) = '\0';

    return rb_funcall(Qnil, rb_intern("send"), 2, rb_str_new2(data), rb_eval_string(params));
}

/* mIRC data representation conversion functions */

void m_repr(VALUE result, char *data) {
    if (NIL_P(result)) {
        strncpy(data, MIRC_NULL, MIRC_MAXSTRING);
    }
    else if (result == Qfalse) {
        strncpy(data, MIRC_FALSE, MIRC_MAXSTRING);
    }
    else if (result == Qtrue) {
        strncpy(data, MIRC_TRUE, MIRC_MAXSTRING);
    }
    else if (FIXNUM_P(result)) {
        _itoa_s(FIX2INT(result), data, MIRC_MAXSTRING, 10);
    }
    else if (TYPE(result) == T_STRING) {
        strncpy(data, StringValueCStr(result), MIRC_MAXSTRING);
    }
    else if (TYPE(result) == T_HASH) {
        strncpy(data, STR2CSTR(rb_inspect(result)), MIRC_MAXSTRING);
    }
    else {
        strncpy(data, STR2CSTR(rb_any_to_s(result)), MIRC_MAXSTRING);
    }
}

static VALUE rb_repr_inum_convert(VALUE result) {
	return rb_str2inum(result, 0);
}

VALUE rb_repr(char *result) {
	VALUE value, tmp_string;
	int status, type = CLBResultType(result);

	switch (type) {
		/* $null in mIRC should really be more analogous
		 * to the empty string "", because there is no
		 * way to represent a nil value in mIRC
		 */
		case CLB_MNULL:		value = rb_str_new2(""); break;
		case CLB_MFALSE:	value = Qfalse; break;
		case CLB_MTRUE:		value = Qtrue; break;

		case CLB_MINTEGER: /* Integer value */
			tmp_string = rb_str_new2(result);
			value = rb_protect(rb_repr_inum_convert, tmp_string, &status); 
			if (status != 0) {
				value = tmp_string;
			}
			break;

		case CLB_MFLOAT: /* Floating point */
			value = rb_eval_string_protect(result, &status);
			if (status != 0) {
				value = rb_str_new2(result);
			}
			break;

		case CLB_MSTRING: /* Normal string value */
			value = rb_str_new2(result);
			break;
	}

	free(result); /* Clear result memory */

	return value;
}

/* Initialization methods */

static void get_ruby_load_path() {
	char *sstr;
    VALUE str, arr;

	sstr = CLBGetLoadPath("ruby -e 'puts $:'");

	if (sstr) {
		str = rb_str_new2(sstr);
		free(sstr);
	    arr = rb_str_split(str, "\r\n");
    
		if (RARRAY_LEN(arr) > 0) {
			rb_funcall(rb_gv_get("$:"), rb_intern("replace"), 1, arr);
			return;
		}
	}

	rb_warn("You don't have ruby installed or ruby.exe is not in your PATH, Ruby's $LOAD_PATH cannot be set.");
}

static void rb_initialize() {
    /* Define some ruby objects */
	RUBYDLL_VERSION = rb_str_new2(MDLL_VERSION);
	SUPPORTED = CLBDirectMessaging() ? Qtrue : Qfalse;
	rb_define_readonly_variable("$RUBYDLL_VERSION", &RUBYDLL_VERSION);
	rb_define_readonly_variable("$MIRC_VERSION_SUPPORTED", &SUPPORTED);
    
	rb_mMIRC = rb_define_module("MIRC");
	rb_define_module_function(rb_mMIRC, "[]", mirc_variable_get, 1);
	rb_define_module_function(rb_mMIRC, "[]=", mirc_variable_set, 2);
	rb_define_module_function(rb_mMIRC, "method_missing", mirc_method_missing, -1);
    rb_define_global_function("mirc", m_eval, -1);

	rb_mOutputHandler = rb_define_module("OutputHandler");
    rb_define_module_function(rb_mOutputHandler, "write", oh_write, 1);
    
    rb_extend_object(rb_stdout, rb_mOutputHandler);
    rb_extend_object(rb_stderr, rb_mOutputHandler);

	rb_mRubyBridge = rb_define_module("RubyBridge");
	rb_define_module_function(rb_mRubyBridge, "execute_method", rbridge_execute_method, -1);
	rb_define_singleton_method(rb_mRubyBridge, "parse_file", rbridge_parse_file, 2);

    /* Pull $: in from the system ruby */
    get_ruby_load_path();
}

/* mIRC exported DLL functions */

int __declspec(dllexport) __stdcall rb_send(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL show, BOOL nopause) {
    VALUE result;

	if (!CLBInitialize(&data)) return 2;

	result = rb_safe(rb_arbitrary_funcall, data);

	if (result == -1) CLB_HALT(data); /* Exception was raised, halt script */

    m_repr(result, data);
	
	return 3;
}

int __declspec(dllexport) __stdcall rb_eval(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL show, BOOL nopause) {
    VALUE result;
    
	if (!CLBInitialize(&data)) return 2;

    result = rb_safe(rb_eval_string, data);

	if (result == -1) CLB_HALT(data); /* Exception was raised, halt script */

	m_repr(result, data);
	
	return 3;
}

void __declspec(dllexport) __stdcall LoadDll(LOADINFO *t) {
	if (!CLBStartup(t, MDLL_SIG)) return;

    ruby_init();
	ruby_script(MDLL_NAME);
	rb_initialize();
}

int  __declspec(dllexport) __stdcall UnloadDll(int mTimeout) {
    if (mTimeout == 0) { /* user called /dll -u */
		CLBShutdown();
    }
	return 0;
}