#include "ruby.h"
#include "../clb/clb.h"

/* DLL information */
#define MDLL_VERSION		"1.1"
#define MDLL_NAME			"ruby.dll"
#define MDLL_SIG			"RUBY"

#ifdef WIN32
#	define strdup	_strdup
#	define strnicmp	_strnicmp
#endif

/* BUGFIX: Ruby likes to override fgetc and fclose, this doesn't seem to work in a DLL */
#undef fgetc
#undef fclose
extern _CRTIMP int __cdecl fgetc(__inout FILE * _File);
extern _CRTIMP int __cdecl fclose(__inout FILE * _File);
