/* MIRC module */
extern VALUE rb_mMIRC;
VALUE mirc_method_missing(int argc, VALUE *argv, VALUE self);
VALUE mirc_variable_get(VALUE self, VALUE var);
VALUE mirc_variable_set(VALUE self, VALUE var, VALUE value);

/* RubyBridge module */
extern VALUE rb_mRubyBridge;
VALUE rbridge_parse_file(VALUE self, VALUE file, VALUE linenum);
VALUE rbridge_execute_method(int argc, VALUE *argv, VALUE self);

/* OutputHandler module */
extern VALUE rb_mOutputHandler;
VALUE oh_write(VALUE self, VALUE data);