#include "common.h"
#include "modules.h"

/* Exported mIRC DLL procedures */
int  __declspec(dllexport) __stdcall rb_send(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL show, BOOL nopause);
int  __declspec(dllexport) __stdcall rb_eval(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL show, BOOL nopause);
void __declspec(dllexport) __stdcall LoadDll(LOADINFO *t);
int  __declspec(dllexport) __stdcall UnloadDll(int mTimeout);

/* mIRC communication functions */
VALUE m_eval(int argc, VALUE *argv, VALUE self);

/* mIRC data representation conversion */
void  m_repr(VALUE result, char *buf);
VALUE rb_repr(char *result);

/* Ruby wrapper function to safely call methods (exception passed to mIRC) */
VALUE rb_safe(VALUE (*func)(void *), void *value);
VALUE rb_arbitrary_funcall(char *data);