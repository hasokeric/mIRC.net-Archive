#include "ruby4mirc.h"

/* OutputHandler module */
VALUE rb_mOutputHandler;

VALUE oh_write(VALUE self, VALUE data) {
	int i;
	char *bufName = (self == rb_stderr ? "STDERR" : "STDOUT");
    VALUE arr = rb_str_split(data, "\n");

	/* Send beginning signal */
	CLBCommandf("%s%s_%s_BEGIN", 0, CLB_SIGNAL_PREFIX, MDLL_SIG, bufName);

	/* Send each line individually */
	for (i = 0; i < RARRAY(arr)->len; i++) {
		VALUE el = RARRAY(arr)->ptr[i];
		CLBCommandf("%s%s_%s %s", 0, CLB_SIGNAL_PREFIX, MDLL_SIG, bufName, StringValueCStr(el));
	}

	/* Send ending signal */
	CLBCommandf("%s%s_%s_END", 0, CLB_SIGNAL_PREFIX, MDLL_SIG, bufName);

    return Qnil;
}

VALUE rb_mRubyBridge;

#define FILETYPE_PLAIN 0
#define FILETYPE_INI   1

VALUE rbridge_parse_file(VALUE self, VALUE r_filename, VALUE r_startLine) {	
	VALUE code;
	FILE *file;
	BOOL multiComment = FALSE, lineComment = FALSE, heredoc = FALSE;
	int line = 1, brackets = 0, size = 4096, fileType = FILETYPE_PLAIN, startLine;
	char ch, lastch = 0, quote = 0, *filename, *buf, *pbuf;

	Check_Type(r_filename, T_STRING);
	Check_Type(r_startLine, T_FIXNUM);

	filename = StringValueCStr(r_filename);
	startLine = FIX2INT(r_startLine);

	/* Check for INI file */
	if (strnicmp(filename + RSTRING(r_filename)->len - 4, ".ini", 4) == 0) {
		fileType = FILETYPE_INI;
	}

	/* Open file */
	file = fopen(filename, "r");
	if (file == NULL) {
		rb_raise(rb_eIOError, "could not open file '%s'.", filename);
		return Qnil;
	}

	if ((buf = (char *)malloc(size)) == NULL) {
		rb_raise(rb_eNoMemError, "could not allocate memory for script.");
		return Qnil;
	}

	pbuf = buf;
	while ((ch = fgetc(file)) != EOF) {
		if (line > startLine) { /* Start parsing code */

			/* Copy the script data into the buffer */
			*pbuf++ = ch;
			if (pbuf >= buf + size - 1) { /* Give buffer more space if needed */
				size *= 2;
				if ((buf = (char *)realloc(buf, size)) == NULL) {
					rb_raise(rb_eNoMemError, "could not allocate memory for script.");
					return Qnil;
				}
			}

			if (lineComment) { /* Inside a # comment */
				if (ch == '\n') lineComment = FALSE; 
			}
			else if (quote) { /* Inside a quote */
				if (ch == quote && lastch != '\\') quote = 0; 
			}
			else {
				/* The reason we're here, counting brackets */
				if (ch == '{') brackets++;
				if (ch == '}') brackets--;
				if (brackets < 0) break;

				/* Entering a # comment */
				if (ch == '#') lineComment = TRUE;

				/* Entering a quote */
				if (ch == '"' || ch == '\'') quote = ch;
			}

			/* Need to strip nNNN= from the beginning of lines in INI files */
			if (fileType == FILETYPE_INI) {
				if (ch == '\n') {
					int ic;
					while (ic = fgetc(file)) {
						if (ic == '=') break;
					}
				}
			}

			lastch = ch;
		}

		if (ch == '\n') line++; 
	}
	*(--pbuf) = 0;

	fclose(file);

	code = rb_str_new2(buf);
	free(buf);

	return code;
}

VALUE rbridge_execute_method(int argc, VALUE *argv, VALUE self) {
	VALUE file, linenum, cache = Qfalse;
	VALUE underscore_file, method_name, code;
	ID method_id;

	// Get arguments
	rb_scan_args(argc, argv, "21", &file, &linenum, &cache);

	StringValue(file);
	Check_Type(linenum, T_FIXNUM);

	// Build method name
	underscore_file = rb_funcall(file, rb_intern("gsub"), 2, rb_reg_new("\\W", 2, 0), rb_str_new2("_"));
	method_name = rb_str_new2("__mirc_method_");
	rb_str_append(method_name, underscore_file);
	rb_str_append(method_name, rb_str_new2("_"));
	rb_str_append(method_name, rb_obj_as_string(linenum));
	method_id = rb_intern(StringValueCStr(method_name));

	if (!rb_respond_to(rb_mRubyBridge, method_id) || !RTEST(cache)) {
		// Method does not exist or we're not using cache, (re)build method

		// Build method definition
		code = rb_str_new2("def ");
		rb_str_append(code, rb_mod_name(rb_mRubyBridge));
		rb_str_append(code, rb_str_new2("."));
		rb_str_append(code, method_name);
		rb_str_append(code, rb_str_new2("\n"));
		rb_str_buf_append(code, rb_funcall(rb_mRubyBridge, rb_intern("parse_file"), 2, file, linenum));
		rb_str_append(code, rb_str_new2("\nend"));

		// Define method
		rb_eval_string(StringValueCStr(code));
	}

	rb_funcall(rb_mRubyBridge, method_id, 0);

	return Qnil;
}

/* MIRC module */
VALUE rb_mMIRC;

VALUE mirc_method_missing(int argc, VALUE *argv, VALUE self) {
	VALUE sym, args, identifier = rb_str_new2("$");

	rb_scan_args(argc, argv, "1*", &sym, &args);

	rb_str_append(identifier, rb_obj_as_string(sym));

	if (RARRAY(args)->len > 0) {
		int i;
		VALUE comma = rb_str_new2(", ");

		rb_str_append(identifier, rb_str_new2("("));
		
		for (i = 0; i < RARRAY(args)->len; i++) {
			VALUE obj = RARRAY(args)->ptr[i];
			
			rb_str_append(identifier, rb_obj_as_string(obj));
			
			if (i < RARRAY(args)->len - 1) {
				rb_str_append(identifier, comma);
			}
		}

		rb_str_append(identifier, rb_str_new2(")"));
	}

	return rb_repr(CLBEvaluate2(StringValueCStr(identifier)));
}

static VALUE mirc_ensure_variable_name(VALUE var) {
	var = rb_obj_as_string(var);

	if (*RSTRING(var)->ptr != '%') { 
		var = rb_str_append(rb_str_new2("%"), var);
	}

	return var;
}

VALUE mirc_variable_get(VALUE self, VALUE var) {
	var = mirc_ensure_variable_name(var);

	return rb_repr(CLBEvaluate2(StringValueCStr(var)));
}

VALUE mirc_variable_set(VALUE self, VALUE var, VALUE value) {
	char buffer[MIRC_MAXSTRING];

	var = mirc_ensure_variable_name(var);

	m_repr(value, (char *)&buffer);

	CLBCommand2f("%s = %s", StringValueCStr(var), buffer);

	return Qnil;
}