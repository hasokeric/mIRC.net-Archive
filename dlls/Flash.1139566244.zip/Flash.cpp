/*
 * Flash.dll by da^hype
 * www.codedb.org
 */
#pragma check_stack(off)
#pragma comment(linker,"/OPT:NOWIN98")
#include <Windows.h>
#include <Winuser.h>

#define mFunc(x) int __stdcall x(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL show, BOOL nopause)
#define mReturn(x) { lstrcpy(data,x); return 3; }

int Numtok(char *szText,char C)
{
	 int num = 1;
	 for (int i = 0; szText[i]; i++)
		if (szText[i] == C) num++;
	 return num;
}

UINT FlashFlags(char *szFlags)
{
	INT iFlags = 0;

	//checks if flags start with +
	if (szFlags[0] != '+') 
			return iFlags;

	for (int i = 1; szFlags[i]; i++)
	{
		if (szFlags[i] == 'a')
			iFlags |= FLASHW_ALL;
		else if (szFlags[i] == 'c')
			iFlags |= FLASHW_CAPTION;
		else if (szFlags[i] == 'f')
			iFlags |= FLASHW_TIMERNOFG;
		else if (szFlags[i] == 'r')
			iFlags |= FLASHW_TRAY;
		else if (szFlags[i] == 's')
			iFlags |= FLASHW_STOP;
		else if (szFlags[i] == 't')
			iFlags |= FLASHW_TIMER;
	}
	return iFlags;
}

mFunc(Flash)
{ 
   int num = Numtok(data,' ');
   //check if there are 4 arguments
   if (num != 4)
	   mReturn("ERROR: not enough arguments");

   UINT iFlags = FlashFlags((char*)strtok(data," "));

   //checks if flags start with +
   if (iFlags == '0')
	   mReturn("ERROR: Flags must start with +");

   //assign values
   HWND m_Hwnd = (HWND)atol(strtok(NULL," ")); //convert int to HWND
   INT iCount = atoi(strtok(NULL," "));
   DWORD dwTimeout = atol(strtok(NULL," "));

   FLASHWINFO flh;
   flh.cbSize = sizeof(FLASHWINFO);
   flh.hwnd = m_Hwnd;
   flh.dwFlags = iFlags;
   flh.uCount = iCount;
   flh.dwTimeout = dwTimeout;

   FlashWindowEx(&flh);

   mReturn("$true");
}
/*
 * Dll Info dialog
 * $dll(Flash.dll,DllInfo,.)
 *
 */
int WINAPI DllInfo(HWND,HWND,char *data,char*,BOOL,BOOL)
{
	MessageBox(NULL, "Made by da^hype (Shahir Reza Ali). www.codedb.org", "Flash.dll 1.0. Malaysian Made", MB_OK);
	return 0;
}