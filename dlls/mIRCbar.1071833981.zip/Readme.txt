mIRCbar 1.6
===========
Copyright (c) 2003 Aaro Hyv�nen - All Rights Reserved
                   aaro.hyvonen@kolumbus.fi

Files:
------
1. mIRCbar.dll     Dll that will draw the bar at the bottom of the screen
2. mIRCbar.mrc     Scripts that control the dll
3. Readme.txt      This file

Installation:
-------------
1. Copy 'mIRCbar.dll' and 'mIRCbar.mrc' in to your mIRC folder(usually 'c:\Program Files\mIRC\')
2. Start mIRC
3. Type '/load -rs mircbar.mrc' to load script in Remotes
4. Type '/barautoon' to set mIRCbar in automatic mode(recommented) or '/baron' to show messages in the bar even when mIRC is in focus

Usage:
------
Double clicking with the left mouse button hides mIRCbar.
Double clicking with the right mouse button will popup settings dialog where you can set the maximum number of lines shown(default 3) and the time how long messages are shown(default 60000ms)
If you screw up with the settings just delete 'mIRCbar.dat' file from your mIRC folder and then restart mIRC and mIRCbar starts with default settings

Commands:
---------
/barautoon         Turns automatic mode on, meaning that when mIRC loses its focus it will turn mIRCbar on and when mIRC has its focus back it will turn mIRCbar off and hide it
/barautooff        Turns automatic mode off
/baron             Turns mIRCbar on so messages show in it
/baroff            Turns mIRCbar off so messages don't show in it, you still can write to it with '/barwrite'
/barhide           Hides mIRCbar
/barwrite          Writes a new line of text in mIRCbar

Thanks:
-------
Tomasz Grysztar    for fasm - http://www.flatassembler.net/
Immo Huittinen     for testing and proofreading this doc