#pragma check_stack(off)

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <commdlg.h>
#include <stdlib.h>
#include <Iphlpapi.h>
#include <shellapi.h>
#include <commctrl.h>

// alias to define an External DLL Command
#define mIRC(x) int __stdcall WINAPI x(HWND mWnd,HWND aWnd,char *data,char*,BOOL,BOOL)
#define Proc(x) LRESULT CALLBACK x(HWND hwnd,UINT uMsg,WPARAM wParam,LPARAM lParam)
#define ret(x) { lstrcpy(data,x); lstrcat(data,"\0"); return 3; }
#define TBAND 150
// default Load DLL structure
HANDLE hFileMap;
LPSTR mData;
HWND mIRC_hwnd;
ULONG o_get,o_snd,get,snd,gets,snds,o_snds,o_gets,s,xyz;
char titleb[1024];
PMIB_IFTABLE ifMIB;
char signal[900];
typedef struct {
    DWORD  mVersion;
    HWND   mHwnd;
    BOOL   mKeep;
} LOADINFO;
WNDPROC mIRC_OldProc;
TRACKMOUSEEVENT mouse;
BOOL IsNumTok(char **str, char chr, UINT *n) {
	*n = 0;
	for (char *p = *str; *p; p++) {
		if ((*p >= '0') && (*p <= '9'))
			*n = *n * 10 + *p - '0';
		else if ((*p == chr) && (p > *str)) {
			*str = &p[1];
			return TRUE;
		}
		else break;
	}
	return FALSE;
}