:::::::::::xCPU Stats 2.0  ::::::::::::::
:::::::::::::::::: Coded by Erarber:::::::::::::::::::::::

---------------------------------------------------
X-files cpu stats is intended to display your computer info.  

 /to the open the main dialog go to menu bar or type /xcpu
---------------------------------------------------
Installation is easy.  Just unzip xcpustats.zip andExtract to your mirc folder root, 
and then in mirc type (remember must be at least 6.01), after this load using command /load -rs $scriptdir/xcpu.mrc


Note: Xcpu stats works only on mirc 6.0+ , so if you don`t have at least version 6.01 update it at mirc.com

EXPLANATION OF FEATURES



:::About::: 
When clicked a small dialog will appear with information about te addon. As well as links to the website and e-mail.


:::Send::: ( New! )

Before you click Send button in main dialog you have to select first the type of msg you want to show.
There are three types of msg. you can display which are : /Msg , /Notice And /Echo . After selecting type Send.

:::Refresh:::
After typing this , your cpu stats will be refreshed that means will display your actual (moment that you clicked refresh) actual stats.

:::close:::
Closes the dialog 

:::Unload:::
To unload script use /unload -rs $scriptdir/xcpustats.mrc 



:::Update:::
Check out the official site of xcpu addon (http://x-filesirc.cjb.net) because i have some neat plans for the future.


:::Version history:::

2.0 - 1.Updated moo.dll to 4.0.3.10 , 2. Added Send button to main dialog which displays your computer stats in channel 3. Removed annoying popups. 4. The addon was 70% recoded.

1.0 - First Public release , now added about dialog , display stats in channel ,unload option , improved main dialog ,
added mdx for better looking and fixed 3 bugs.

0.5b - second release , fixed bugs , updated moo.dll

0.2 - first release



:::Credits:::
Mark Hutton- for the brillant moo.dll from www.influenced.net
DragonZap - for the best mirc dll ever mdx.dll 
SkinArt - * helped me about mdx alias 




:::contact:::
Website - www.x-filesirc.cjb.net ( www.x-filesirc.com coming soon )
Email - eri_2222@hotmail.com (adress of msn too)
Irc - chatworlds ( irc.chatworlds.net ) channel #help . (nick X-FILE , MetallicA )

Copyright 2003 X-FILE


If you have any ideas for xcpu stats, please email me at
eri_2222@hotmail.com . You can email me also if you have any bugs to report. Alternatively,  check out the website for more updates.

