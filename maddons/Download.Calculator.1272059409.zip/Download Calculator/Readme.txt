; Download Calculator v4.0 by Jigsy.
;
; To install this file please copy and paste into remotes, or save and /load -rs P:ath\to\dCalc.mrc in any mIRC.
;
;
; Contact:
; --------
;
; If you find any bugs or have any suggestions then feel free to contact me using either method displayed.
;
; E-mail: JigsWithoutWoodstock [at] gmail [dot] com
; IRC:    irc.globalgamers.net:6667 as Jigsy. (I hide what channels I'm on, so you'll need to find me. -- Do /list and check the larger ones.)
; Site:   http://jigsy.ath.cx/
;
;
; Use:
; ----
;
; Calculates the estimated download time based on size/speed.
;
; The addon is pretty straight forward to follow, input numerical values into the edit boxes and select what type of size it is (byte, kB, etc.)
; and click "Calculate".
;
; To run the addon simply type "/dcalc" or select Download Calculator from the menubar.
;
;
; You can also reference the addon outside the dialog using $dtime.
;
; $dtime(<filesize>,<speed>,[byte|kB|MB|GB|TB|PB],[byte|kB|MB|GB|TB]/s)
;
;
; Examples:
; ---------
;
; //echo -a $dtime(1,1,GB,MB/s)                 returns 1024
; //echo -a $dtime(5.37,124,MB,kB/s)            returns 44.345806
; //echo -a $dtime(2.4,1.6,TB,MB/s)             returns 1572864
;
; If you wish to style it, use the $s2l identifier included.
;
; //echo -a $s2l($dtime(1,1,GB,MB/s)).peak       returns 17m 4s
; //echo -a $s2l($dtime(5.37,124,MB,kB/s)).peak  returns 44s
; //echo -a $s2l($dtime(2.4,1.6,TB,MB/s)).peak   returns 2w 4d 4h 54m 24s
;
; ... You get the idea.
;

; EOF