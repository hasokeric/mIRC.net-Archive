
 " control Away system "

Installing:
Use /load -rs control Away system .mrc
The addon can be put anywhere, as all references are $scriptdir,
I have it in mircdir/controlAwaysystem





Known Issues:
This is unlikely to function correctly with a full script, if you are using
one, it may be possible to disable your full scripts away system and use this,
but it will vary depending on how badly written the full script is :)
Triggers can sometimes bugger up if you have a lot of them.
The away system occasionaly becomes confused, I duno why yet :/

Feedback:

EMail: eric.basher@lycos.co.uk


Thanks :)

5:52 AM 9/11/2003