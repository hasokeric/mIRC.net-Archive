Readme File For "On Event, Sound Setting" 1.0 By Youthanasia.


This Addon will help you to set audio files which will play
automaticly when the event takes place.


1. In order To Load The Addon, go to your mIRC and type:
   /load -rs LOCATION\eventsounds.mrc
   
   *** Replace the "LOCATION" with the Full path to the extraction
       place, e.g D:\mirc\Bla\eventsounds.mrc

2. Open the dialog by typing:/ssound

3. In order to select a sound to an event, simply select the wanted
   (make it blue...heh) and press the "Edit" button.
   a selcetion dialog will open, selcet an audio file
   (only!!! .WAV , .MP3 , .MID)

4. To enable or disable the Event's sound, check or uncheck the check
   button nect to the wanted event.

5. You can test the sound pressing on the "Play" button. First select
   an Event and only then press the button.

6. You can stop the sound by pressing "Stop" button.

Please DO NOT change any of the files, it will only damage the addon!


Have fun,

Bugs, Comment, Love Letters to: doometal@hotmail.com

Or find me in : www.mirc.net , User Name: Youthanasia
Or on mIRC: DalNet, Youthanaia, #l0ners , #helpdesk , #HebHelp
       