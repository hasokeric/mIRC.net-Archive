psyBNC addon script for mIRC 6.03

(c) inferno 2003




[---------------------------------------------------------------------
[ description
[---------------------------------------------------------------------

  a frontend for psyBNC (GUI, etc)
    clueless? google

  note: if you don't know what a lot of these features are and do, 
          please ask. but if you're using psyBNC you should know.


[---------------------------------------------------------------------
[ history 
[---------------------------------------------------------------------

7.06-  (1) redesigned setup dialog, added more features
           added: ability to jump to a different server through dialog
           added: more buttons on the bottom right 
                  set - username, away message(if on)
                        leave message (on quit)
       (2) now each server has its own options, there are no longer
	     gloal options
       (3) message dialog is now better looking and larger, however
             it will still not popup if you dont have any messages
             even though you clicked "messages"
     
7.03-  (1) bug fixes (dcc related), couple added features
6.21-  (1) first release, includes basic server listing, allowing
 
             auto-connect to bnc server, a few options for every server

             and some global options (including basic things)

       (2) dcc-enable custom windows, if dccenable is set to 1, any

             dcc requests are sent through the bouncer, a window will pop-up

             when this occurs, dccs are still sent through the bouncer and

             you must use /dccsendme  when the transfer is complete



  caveats-
 
       (1) if you click messages and there are none, nothing will happen.



[---------------------------------------------------------------------
[ installation 
[---------------------------------------------------------------------

(1) extract all of the files into the same directory

(2) open mIRC and type:

      /load -rs psybnc.mrc




[---------------------------------------------------------------------
[ usage
[---------------------------------------------------------------------


(1) right click on the status/channel window, click psybnc->config

(2) click add to add a server and follow instructions


      everything else is self-explanitory



(3) once a server is added, you can click rem to remove or con to connect
      to that server
(4) if you click dcc's (and dccenable is on) it will bring up a window
      detailing all the dcc's going through the bouncer
(5) clicking messages will bring up the message window (if you have any)

[---------------------------------------------------------------------
[ server dialog details
[---------------------------------------------------------------------


add: to add a server
rem: to remove a server
con: to connect to that server
send pass on login: to automatically send the password (/quote pass <pass>)


psyBNC nick: the nickname of the bouncer (usually -psyBNC)
msg filename: the filename to store messages (for this server)


jump: to jump to the server listed in the connect to box
connect to: this dropbox details all of the servers you have added
             currently psyBNC only supports 9.


away: set your away message (upon leaving, if applicable)
user: set your username, ie: infy@damnit.org, infy is the username
leave: set your message upon quitting your irc client



[---------------------------------------------------------------------
[ questions
[---------------------------------------------------------------------

(1) email me: infy@damnit.org




[---------------------------------------------------------------------
[ bugs
[---------------------------------------------------------------------



(1) email me: infy@damnit.org

