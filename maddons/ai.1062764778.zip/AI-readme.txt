Auto Nicknames Identify System, By Youthanasia

find me in DalNet irc network in: #scripting,#l0ners,#crapshack
or: doometal@hotmail.com



Installing:

1. unzip file into some dir (recommended it will be somewhere inside you
   mIRC dir)

2. goto mIRC and type this: /load -rs PATH/autoidentify.mrc
   PATH = the path where you unzip the files.

3. open the dialog by tying: /ai
   or thtough menubar/stauts/channel popups

4. in order to add a nickname to the auto identify list, simply click
   on "Add" button and follow.
   the "command" need to be without the password (e.g: /nickserv identify)

5. to delete a nickname select the wanted line and press "Del"

6. to enable/disable identify to a specifiec nickname, check/uncheck the
   checkbox near the wanted line.

7. to disable the autoidentify uncheck the "enable" checkbox.

8. To show/hide the passwords , check/uncheck the "hide passwords" checkbox

9. to read this help file, press "Help" button.

10. to unload this great sweet awsome beautiful addon type: 
    /unload -rs autoidentify.mrc OR unload it through remote (alt+r --> file, unload)

** the addon works not only on connect but whenever identify is needed.

enjoy.
