mIRC Clone Script v1.7

********m ���� : INSTALLATION**********

1. Download the file (Hopefully this is already done, if not, download from: http://www.leet-network.net/upload/MClone.mrc
2. Copy the MClone.mrc file into any directory you want
3. Open up mIRC
NOTE: If you put MClone.mrc in your mIRC's main directory, just do /load -rs MClone.mrc
Otherwise, go to step 4
4. Go to the Scripts Editor Tools -> Scripts Editor -> "Remotes" Tab (ALT + R)
5. Now go to File -> Load -> Browse for the file MClone.mrc, and open it
6. For instructions on how to use this script, scroll down to the "USAGE" section.


********m ���� : UPDATES**********
OLD:

*Fixed more bugs
*Added /me command message
*This window :P
*Fixed even more bugs I could find
*Added an updater
*Added Instructions Section
*Added Channels List
*Fixed messaging lines bug
*Dialog now opens up on the Desktop instead

NEW:

*All timers silenced
*Size of the server console has been reduced
*Changed the layout of the server console
*Fixed the "$did line 104" error
*Minor changes such as scrolling

***Bottom left area is empty for now, it will be where I put in a new feature
***This was an immediate update to fix most/all errors and make needed changes


********m ���� : INFO**********


This Script is used to simply make a clone on mIRC.
It doesn't have a billion features (You have mIRC for that), 
this is only to make a simple clone quickly.
NOTE: This will NOT support SSL connections. 
IE: Connecting to a server with port +6697 won't work
Feel free to edit the code as you please. If the script stops working, you did a bad thing...
so just re-download it.

I also made this script specifically to open up on the desktop. The raw server info needs
a lot of space to be shown. For that reason, I made the actual Server Console open on the
desktop instead of opening on mIRC itself and taking up space.

Also, this script isn't perfect. 
Obviously there might be more bugs, its an mIRC script.
Thank you Behemoth for testing and finding most of the bugs. 
Any future suggestions are accepted.

NOTE: There is a use of a lot of timers in some places, but all of them last
less than 5 seconds. Only about 3-4 timers in the entire script. Go search, 
I'm lazy. They are also silenced. This script might give errors if you improperly
connect to a server, or you connect to a server on default settings on mclone
without being connected to a server through mIRC first.


********m ���� : USAGE**********

To open up the dialog, right click in any mIRC window, and choose mIRC Clone
NOTE: After opening it up, I would recommend checking for updates first. If "Update" is grayed out, you have the latest version.
(I). Go to the Main Console
(II). Put in the server name and Port
(III). Press Connect

Extra:

Default Settings ONLY work if you are currently
connected to a server. The default settings put
in  are your current server, the current port, your
current Nick with -Clone added to it, and it 
doesn't make you auto-join any channels. Once 
again, do NOT put in an SSL port such as +6697.

The "Misc Info" means you can switch the nick you
use to connect with, and you can choose to autojoin
one channel.

The update ONLY works if you do NOT have the most
latest version. If you have the latest version, the
Update button will be grayed out automatically.

********m ���� : CONTACT**********

You can contact me at the following:

-IRC-

Nick: Favdaman
Server: irc.dynastynet.net
Channel(s): #dynasty, #xbconnect

-Email-

Favdaman@Leet-Network.net
Favdaman@XBConnect.com



