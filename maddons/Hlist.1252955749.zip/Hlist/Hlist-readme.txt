Hlist v2.0 Hash table handling script
Copyright � (c) 2006-2009 Kashin
All Rights Reserved.

					    - Index -

- What is Hlist?
- How to use?
- History
- Contact



					- What is Hlist? -

Hlist is a tool for searching through your hash tables internally in mIRC with the option to load an external table.
Hlist supports the most normal search function, "iswm" aswell as a bunch of other "if then else" checks.
Besides that Hlist also contains an exclude function so that you have an even more powerfull search experience. 



					 - How to use? -

Command for opening Hlist: /hlist [Table] [Item] [Data] [Exclude.Table] [Exclude.Item] [Exclude.data]

The dialog is pretty self explaining, but should you have some doubt here are the basics:
On the left side of the dialog you will find three edit boxes (default), in here you can enter Table, Item, and Data.
You do not need to fill all of the boxes; e.g. you can limit your search to match the data '3' simply by entering 
'3' in the data box and press the 'Start search' button.

Below the three edit boxes you there is an drop down menu, this contain the different 'if then else' methods that you
can use when searching your tables. Note that when using iswm and iswmcs that you need to provide the wildcards (*).
Searching for 'Test' and '*test*' is two different stories.

For more information regarding the 'if then else' statements type '/help if then else' into mIRC.

For an even more advanced searh, Hlist now has the ability to exclude items from your search. To use this feature you
will need to drag the exclude bar up so that its edit boxes and dropdown menu are shown.
The exclude bar works just like the regular search bar, except that it now excludes matches from the final result.

The Search Settings bar has three different settings for fast access:
1. Max searches
� Here you can enter how many searches that can be open at a time, it's not recommended to use more than 9.

2. Max items
� Here you can enter how many items and table must MAXIMUM contain to be allowed to show in results.

3. Ignore ascii/chr
� Here you can enter the $ascii or $chr that will be used when searching with the hlist startup command.
Command: /hlist [Table] [Item] [Data] [Exclude.Table] [Exclude.Item] [Exclude.data]
Now instead of having to fill everything you can use the selected $chr (default: $chr(45)/ - ) to act as an empty
search parameter.
e.g. /hlist - *.chanlev* - *#Chan*

You do not have to use more then the required parameters. As shown above.





					- History -

January 10th, 2009.
Version 2.0
� Released
� Main new feature is a DCX supported dialog rather than echos and @windows.



					- Contact -

You can contact me (Kashin) on QuakeNet, i usually hang around in #Kashin and #vliedel.
I'm happy to hear about suggestions, bugs, and whatever you feel need said.



					- Authors comment -

Enjoy

Kashin