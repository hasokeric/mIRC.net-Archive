mIRC Away System
--------------------------------------------

* Function:

    - Simple away system with the following options:
      - away reason (advanced add/remove function)
      - away nick (advanced add/remove function)
      - pager/logger
      - multi-serv (all networks)
      - silent away
      - fast away command:
        command: /away -[lmnps] <reason>
        - flags:
                 l = logger on
                 m = multi-serv (all networks) active
                 n = use last used away nick
                 p = pager on
                 s = silent away

                 NOTE: if no flag is specified the last setting are used.
                       if no reason is specified "afk" will be used.
      - msg editor available from the menubar popup.
      - settings are stored in the script itself, so even on unload you're settings are still there.
      - support for dirs with spaces
      - sleek dialogs :D

* How to install?

   - place the mas.ini in your main mircdir or a subdir of that.
   - open mirc and enter: //load -rs $findfile(" $+ $mircdir $+ ",mas.ini,1)
   - you're done
   - you can open the message editor by typing /eam or using the menubar popup
   - to set yourself away, type /away -[lmnps] <reason>, use the popups or type /mas
   - to unload, select the option "Unload from the "mIRC Away System" menu in the menubar popup

* Comments

   - This is an update of the previous one and should work a bit better
   - visit http://www.airliner.nl/
   - Do not use anything from the mas.ini file included in this package without my permission
     you can contact me by email: webmaster@airliner.nl
                   or trough irc: /server irc.darktides.net -j #webdevelopment

-------------------------------------------

 Enjoy, grtz,

 airliner	webmaster@airliner.nl		http://www.airliner.nl/  