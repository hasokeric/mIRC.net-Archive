[]------------------------------[]
[] GTAeroIRC Calculator Script
[]------------------------------[]
[]
[] .- 1.00 Introduction
[] |
[] |- 1.50 Loading the Script
[] |
[] |- 2.00 Commands
[] |
[] |-- 2.01 /calculator
[] |-- 2.02 /calculator RUN
[] |-- 2.03 /calculator README
[] |-- 2.04 /calculator UNINSTALL
[] |
[] |- 3.00 Calculator Functions
[] |
[] |-- 3.01 Negatives
[] |-- 3.02 Addition
[] |-- 3.03 Subtraction
[] |-- 3.04 Multiplication
[] |-- 3.05 Division
[] |-- 3.06 Pi
[] |-- 3.07 Percentages
[] |-- 3.08 Fractions
[] |-- 3.09 Absoloute Value
[] |-- 3.10 Powers
[] |-- 3.11 Roots
[] |-- 3.12 Grouping
[] |
[] |- 4.00 Whats Expected from Version 2?
[] |- 5.00 Copyright Information
[] `- 6.00 Contact Information
[]------------------------------[]
[]---> Section 1.00
[]---------------------
[] Introduction
[]------------------
[]  Calculators have been favored by many, with their huge usability
[] to do functions and help us with our equations.  They have been
[] scripted, however, only by an elite few.
[]------------------------------[]
[]---> Section 1.50
[]----------------------
[] Installing the Script
[]-------------------
[]  To Install this script, make sure that it is extracted to a location.
[] Remember that location, it is very important.  Once you have done that,
[] open up your mIRC program and type:
[] //load -rs $shortfn(<location>calculator.gprg)
[] Replacing, of course, <location> with the file directory you placed the
[] script in.  So, it should look like:
[] //load -rs $shortfn(C:\mirc\scripts\calculator\calculator.gprg)
[]
[] --> NOTE: Just an Example, it might not be installed to that directory.
[]------------------------------[]
[]---> Section 2.00
[]----------------------
[] Commands
[]-------------------
[] 2.01 - /Calculator
[]-----------------
[]  Typing the command, /calculator, opens up the introduction file,
[] which tells you just a basic little bit about the calculator program
[] itself.  The Introduction played, is the exact same as the introduction
[] that was played when the program was loaded.
[]-------------------
[] 2.02 - /Calculator RUN
[]----------------
[]  This command runs the calculator program. Basically, it just opens
[] the dialog that the calculator was programmed in.  Once that is open
[] you can use the calculator, just like an ordinary one, except for a few
[] details.
[]
[] -> Square Roots are Calculated AutoMatically before being put in.
[] -> Absoloute Value is Calculated AutoMatically before being put in.
[] and
[] -> Percentages are Calculated AutoMatically before being put in.
[]
[]  These objects may not be changed in the future, only time will tell.
[]-------------------
[] 2.03 - /Calculator README
[]----------------
[]  This command displays the ReadMe File (what you're reading now!) in a 
[] new window.
[]-------------------
[] 2.04 - /Calculator UNINSTALL
[]----------------
[]  This command brings up the Uninstall Information, which will allow you
[] to not only uninstall the program, but to delete all of the files it uses
[] including this readme!
[]------------------------------[]
[]---> Section 3.00
[]---------------------
[] Calculator Functions
[]------------------
[] 3.01 - Negatives
[]---------------
[]  Hit the Negative Key before entering a number to make it a Negative, it may
[] not be changed back.
[]-------------------
[] 3.02 - Addition
[]---------------
[]  Addition is the adding of two or more numbers together.  Just type in the
[] first number, the "+" button, and then the second number, etc until you have
[] all the numbers you wish to add.  Then press the "=" sign to get your answer.
[]-------------------
[] 3.03 - Subtraction
[]---------------
[]  Subtraction is the minusing of two or more numbers together.  Just type in the
[] first number, the "-" button (either of them work), and then the second number, etc 
[] until you have all the numbers you wish to subtract.  Then press the "=" sign to get
[] your answer.
[]-------------------
[] 3.04 - Multiplication
[]----------------
[]  Multiplication is the multiplying of two or more numbers together.  Just type in
[] the first number, the "x" button, and then the second number, etc until you have all
[] the numbers you wish to multiply.  Then press the "=" sign to get your answer.
[]-------------------
[] 3.05 - Division
[]----------------
[]  Division is the dividing of two or more numbers.  Just type in the first number, the
[] "�" button, and then the second number, etc until you have all the numbers you wish
[] to divide.  Then press the "=" sign to get your answer.
[]-------------------
[] 3.06 - Pi
[]----------------
[]  Pi is called by the $full.pi parameter, which equals 3.1415926535897932384626433832795
[] To use Pi, just type the "Pi" button.
[]-------------------
[] 3.07 - Percentages
[]----------------
[]  To find the Percent of a number, click the "%" button before typing the number.  Then
[] insert the number of the percent you want in the Box that pops up.  It will calculate the
[] percentage and insert it into the calculator box.
[]-------------------
[] 3.08 - Fractions
[]----------------
[]  To find a fraction, just hit the "x/y" button before typing the numbers for the fraction.
[] It will ask you what to input for the x and y, and then it will insert the fraction into the
[] calculator box.
[]
[]  Fractions are found by this below method:
[] x/y = x�y
[]
[]  All answers you receive will come out in Decimal form, not fraction form.
[]-------------------
[] 3.09 - Absoloute Value
[]----------------
[]  To find the absouloute value of a number, click the "|x|" button on the calculator, then
[] type in the number you want the absoloute value for, it will calculate it there on the spot
[] and enter it into the calculator box.
[]
[] Absoloute Value is the Amount of Numbers a Certain Number is away from 0.
[]-------------------
[] 3.10 - Powers
[]----------------
[]  To find a number squared, cubed, tessered, or to a different power, click the "x^y" button
[] on your calculator.  It will ask you what to insert for x and y.  X is the number you want
[] to be squared/cubed/tessered/whatevered and y is the Power that you are Whatevering it to.
[] Powers are calculated on site and inserted in the box.
[]
[] x squared  = x^2
[] x cubed    = x^3
[] x tessered = x^5
[]-------------------
[] 3.11 - Roots
[]----------------
[]  To find a root of a number, click the "-./''''''" button on the calculator.  It will open a dialog
[] asking for the number you want to find a root of, and the root you want to find of the number.
[]
[] (x) What Number? = Number you want the root of.
[] (y) What Root?   = Equals the Root you want the number rooted to.
[]
[]  Roots are calculated by the following.
[] x^1/y
[]-------------------
[] 3.12 - Grouping
[]----------------
[]  To start a group to be calculated first, press the "(" button, then type in the stuff you wish to 
[] group together, and then press the ")" button.  You can even have groups inside of groups!
[]
[] X+2-(67xY-2(6-(-5)))�3
[]------------------------------[]
[]---> Section 4.00
[]---------------------
[] Whats expected from Version 2.0?
[]------------------
[]  You can expect alot from Version 2.0.  We will just say it will include many more features and 
[] stuff then it did in v.1.0, infact, it will basically be rescripted.  Here is a *small* list of
[] included features.
[]
[] --> Logging Enabled/Disabled
[] ---- Chose weather you want to log your equations or not.
[]
[] --> !NEW! $math Functions
[] ----  Forget opening the Calculator, do you need to call something for a script, such as the factorial
[] ---- of 5 (5!) or something like that?  You will be able to do so using the !NEW! $math commands.  Here
[] ---- are some brief examples:
[] ----
[] ---- $math.factorial(5) will calculate the Factorial of 5 (5!) => 5*4*3*2*1 = 120
[] ---- $math.root(4,2)    will calculate the root (2) of a number (4) => 4^1/2 = 2
[] ---- $math.percent(50)  will calculate the percent of a number (5) => 50/100 = .50
[] ---- $math.abvalue(-30) will calculate the absoloute value of a number (-30) => -30*-1 = 30
[]------------------------------[]
[]---> Section 5.00
[]---------------------
[] Copyright Information
[]------------------
[]  The GTAeroIRC Calculator is Copyright (C) 2005 by Navarr T. Barnier and Project: Grand Theft Aero.  No part
[] of this calculator may be reproduced in part or in whole unless by signed written authorization from the creator
[] of the script.  The Icons/Script/ReadMe/and Intro files may not be used without the creators written and signed
[] permission.
[]------------------------------[]
[]---> Section 6.00
[]---------------------
[] Contact Information
[]------------------
[] Email: navarr@gmail.com
[] WEB  : www.gtaero.net
[] 4IM  : GTA_Navarr
[] AIM  : navarr6
[] YIM  : navarr6
[] MSNIM: custserv@gtaero.net
[] ICQ  : 228474592
[] IRC  : /server -m irc.gtaero.net -j #gtaeroirc