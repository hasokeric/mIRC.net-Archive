WorldofWarcraft.com User Lookup v1.0

Installation:
Extract the contents of this zip to any folder (together)
Run mIRC (Skip this if it is already running)
Type /load -rs path/to/file/wow.mrc
-ie: /load -rs C:\Program Files\mIRC\wow.mrc
Edit wowscript.cfg (Open with notepad)

Purpose:
Uses public triggers to look up users on WorldofWarcraft.com and display information
Note 1: Requires you to know the user's realm, name, and faction (horde/alliance)
Note 2: User must be ranked in the top 20,000 pvp (honor) wise on his realm and faction
Note 3: Blizzard only updates this information once every week

Usage:
Depends on your configuration in wowscript.cfg. Default is !wow <realm> <faction> <name>

Release Notes:
v1.0 - Initial Release, simple name look up.

Author:
aca20031 (Adminion or 1stAdmiral), Benjamin Buzbee

Contact Information:
For help or suggestions...
IRC: irc.st0rmgaming.com, irc.quakenet.org #scripting
Email: 1stAdmiral@gmail.com