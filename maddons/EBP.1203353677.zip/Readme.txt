########## Easy Ban Protection v2.0 ##########
##############################################
##  Easy Ban Protection v2.0                ##
##  Author: |Red_Bu||                       ##
##  Created: 26.06.2007                     ##
##  Copyrighted 2001-2007 to |Red_Bu||      ##
##  Email: ole@team-future.com              ##
##############################################
##############################################


THANK YOU for downloading and (hopefully) using this addon!


------------------
1. Information
2. Version history
3. Installation process
4. Disclamer
5. Author's Msg
------------------



=>Information<=
Easy Ban Protection will protect you as an OPerator (@) of a channel
from getting banned from other OPerator's (@).


=>Version History<=

Easy Ban Protection v2.0:
=========================
* Updated dialog
* Removed Help Dialog
* Added error messages when banned in channels you do not have OPs in
* Checks to see if you are a OPerator (@) in the channel the ban was performed
* When unloaded it will unset variables the addon have created/used
-------------------------

Easy Ban Protection v1.5:
=========================
* new dialog 
* added so you can choose your own penalty.. read more above for more information!
* Removed the status thingy'ss
-------------------------

Easy Ban Protection v1.4:
=========================
* new dialog
* Protects you in all channels!
* enter a message in the dialog and the message will be sent to the person who tried to ban you!
* added a nice Help dialog too
-------------------------

Easy Ban Protection v1.3:
=========================
* Now in a nice dialog
-------------------------

Easy Ban Protection v1.2:
=========================
* It now also deops the person who tried to Ban u!
* new cool dialog
-------------------------


=<Installing The Addon>=
Never installed an addon before? Well I'll try get you through it..

1. Extract EBP.rar to your mIRC directory! (you need winrar for this, download it from http://www.rarlab.com/)
2. Open your mIRC client (double click mirc.exe) 
3. You dont need to be connected to and server to load an addon. so the next thing you do is:
   write this in the status window: (it dont have to be the status window though) /load -rs EBP.mrc
   You should than get a little Script Warning.. it tells you that the script/addon has some initialization
   commands, and wonder if you want to run them.. Click YES on this one!
   Now you should have gotten some Information regarding the addon. Remember now.. if you have extracted
   the EBP.mrc file into another directory.. Example: (C:\mIRC\System\EBP.mrc you have to write:
   /load -rs system\EBP.mrc and so on if you got any more subdirectories.
   You should now be able to access the dialog by the Status window, Channel window and the Menu-bar.
   You can also access the dialog by using the command /ebp

Well, EBP.mrc should now be installed and ready to be launched! but if you still got problems
be sure to email me! Email address you can find further down in this helpfile.


=<Disclamer>=
This addon/script is provided without warranty of any kind. In no event shall The addons/scripts Author
be liable for any damages whatsoever caused by the script's any related files, 
even if the Author has been advised of the possibility of such damages. 
This addon/script may not be distributed as a part of any commercial package. 
All rights of the addon/script are owned by the author. 
Any violations to the script's copyrights will be prosecuted by the law. 
(Rights of the external programs in the script are owned by their respective authors.)


=<Author Announcements>=
Slowly starting to script again from a long break, and since this little addon has been a big success,
I found it deserved to get some attention and fixes/changes.
Getting short on ideas of this addon though, so any tips/suggestions are most welcome!



NB: This addon is only for personal use, you are not allowed to rip it or lease it on the internet
    without the authors (|Red_Bu||) permission. (Read Disclamer!)



=<Contact Information>=
Email: ole@team-future.com
Site: N/A (Under construction)
ScriptTeam: Team-Future


Enjoy! 
Greetz ;-)