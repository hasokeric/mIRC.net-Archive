TVRage.Com mIRC Addon By Gecko321

To Load: Type /load -rs1 tvrage.mrc

Commands:

!ep <Show> (Season and Episode) EX: !ep House 2x05
!ep Schedule <Day Of Week> EX: !ep Schedule Fri
!ep Schedule <Day Of Week> (Time)  EX: !ep Schedule Wed 10 
!ep Schedule <Day Of Week> (Time) (Country:US,GB,UK,AU) EX: !ep Schedule Saturday 10 GB
Options in ( ) are Optional. Options in < > are Required.


If You have any question you can E-Mail me: JeepXJ92@Gmail.com