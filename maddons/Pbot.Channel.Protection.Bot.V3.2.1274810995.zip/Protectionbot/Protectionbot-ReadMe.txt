Hello, Dear user thanks for trying out pbot channel protection.

To load:
1: In your mIRc window type /run . and paste the protectionbot folder in the explorer window that comes up.
2: Then press alt + r and select file/load browse for the file "protectionbot.mrc" and load.


Type /pbhelp to contact the pbot help centre, if that does not work please email irccompanion@gmail.com
Please read the testomonials below. 

Forever in service of you dear user.

Thank You.


######################################
#real emails sent to pbot help centre#
######################################

I own a channel on a large network which was constantly getting spammed. We already had bots in place but the spammers found a way round them. Since is use mirc i decided to try pbot. I don't think you explain how clever pbot actually is. The spammers tried to flood by changing nicks loads of times and pbot banned them, then they tried to only change nicks one user at a time (in an attempt to defeat pbot) but right after each other. Pbot detected this and set the channel +N. My channel now is basically spam free and users can now start chatting again. Thank You. 

-

Thank You for a great script. I am an IRC operator on a network and I have pbot running 24/7 to gline TOR and Proxies as well as protecting all the main channels from flooders. 

-

Great Work thanks.

-

I have a small channel on a network and the admins refuse to assign a bot to protect it. Thanks To pbot My channel is attracting users again after ridding the bloody trolls from it. 

-

I am head admin on a christian irc network that was subject to numerous botnets. Pbot has performed stunningly in every attack. I just noticed the option to auto gline connecting botnets, and now they don't even enter the channels. Thank-You and G-D bless. 

-

I am an op on a major network. We found that we cannot do without pbot, thanks for your script. Can we have an update facility please?

-
Hey :D 
 
This script is the best i have seen in a long time!! easy to setup and well laid out for me to use on my network :D 
very nice features such as the scan on connect (already got a match this morning :D!!) 
 
Please keep working on this bot, dont let it die like sooo many other scripts out there (like pnp etc) 
-
thank u dude this BOT IS AWSOME NOW :D
-