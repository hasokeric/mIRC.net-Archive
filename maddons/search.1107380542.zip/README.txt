Alright, to install this Script, just extract it to a file (make sure you remember where the file is located)

Go to your mIRC client, and type //load -rs $shortfn(<folder that the file is located in>search.mrc)

It should look something like //load -rs $shortfn(C:\mirc\Search Program\search.mrc)

Type that and its installed!  Then just go to your Toolbar, and its under GTAeroIRC Search

Open opens up the dialog, its self explanitory

Unload unloads the script for you.

Made by Navarr T. Barnier