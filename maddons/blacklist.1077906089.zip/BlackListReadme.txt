Fat's BlackList Addon, By Youthanasia.
This Is A Help File, Use It!
Contact me at: doometal@hotmail.com
IRC: DalNet Network, nick: Youthanasia.

Intruduction

   This Addon suppose to let you keep your "enemies" out of a channel you're
   opped in. The addon can remember Hosts Or Nicknames and kick/ban/kick&ban them
   depends on your settings.
   REMEMBER this can get out of hand if you're not setting this right.
   DO NOT make this addon into a war addon, this is simply a user kicker!


Install
   1. unzip the file into some directory, i suggest it will be somewhere inside your
      mIRC directory, but it should work anyway.
   2. Go to your mIRC, and type: //load -rs PATH/blacklist.mrc
      REPLACE!!! "PATH" with the location of the file. (blacklist.mrc)
   3. The Script will /echo you some information about the addon, read it and have fun.
Help
  1. In Order To Open The Dialog, search in channel/status/menubar Popups this:
     "BlackList" and click.
  
  2. In Order To Add Nickname/Host click on the "Add" button and insert a
     Nickname/host and a reason (optional), if the reason is null, the dfault
     reason will be in the kick reason.

  3. To del Nickname/Host, select the line and click "Del".

  4. To set the Punish select between the Radio Buttons Kick/Ban/Kick Ban.
 
  5. In order to make a Temp ban (a bvan which remove itself after a given time)
     check the "Temp Ban" check.

  6. Set the Temp Ban time in the edit box near the "Temp Ban" check.
 
  7. To set the default kick reason (which will appear if no reason mantioned) simply
     enter the reason into the Edit box inside the "Default Kick Reason" Box.

  8. In order to prevent BlackList to act in a channel(s) you're opped in, just enter
     The Channel(s). if more then one channel, put "," between them (e.g: #chan1,#chan2)

Enjoy, and don't be stupid.


