Welcome Back system by Youthanasia.



Install: 
  extrct the zip file to any directory.
  open your mIRC client and type: /load -rs PATH\wbsys.mrc
  where PATH is the path to the file (e.g: c:\mirc)

to open the addon press: /dialog -m wb wb
or use the channel popup menu.



1. Adding Info For A Nick:

    In order to add info about a nick:
    Can Be Done inside the dialog by Pressing "Add" button 
    
    OR you can also use the Nicklist Popup menu....

2. Deleteing Info For A Nick:

     Can Be Done inside the dialog by Pressing "Del" button After
     selecting the wanted line form the list.
    
     OR you can also use the Nicklist Popup menu....

3. Set The Join Msg
   
   Type into the middle edit the msg that wil appear in the channel.
   e.g: Infoline For: @nick - @info
   
   @nick = the nickname
   @info = the infoline you've wrote about this nick.

4. Disable The Addon in some channels

   By Typing Channels name into the bottom edit the addon will avoid from
   sending info msg into those channels.
   supperate the channels by ","
   e.g: #chan1,#chan2,#chan3
  
5. to Disable the whole addon check\uncheck the "enable" check.



any questions,bug reports and whatever....
here: doometal@hotmail.com


