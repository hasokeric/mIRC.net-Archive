 =====================================

  xSeen
  version 3.9
  Written by: xDaeMoN
  Email: xdaemon@xdaemon.us
  12.28.06
   
 =====================================


 --------------
  INTRODUCTION
 --------------

  A Multi-Server Seen system that has seen notification and more. 

---------------
 REQUIREMENTS
---------------

  mIRC 6.16-6.21


 ----------------
  HOW TO INSTALL
 ----------------

  Unzip the xSeen.zip file to a folder on your hard drive.
  Open mIRC. 

  Then you can do:

  1.
  Go to the remotes editor (Alt +R) and select File -> Load -> Script. 
  Browse to the xSeen.mrc file that you extracted from the .zip.
  Press "Open." 
  Press "Yes" if asked to run setup routines.

   -OR-

  2.
  type:

     /load -rs path/to/xSeen.mrc

  Note: If you are using version 3.5 & below of this script, please do a fresh install as your old data
	files will not work anymore since I re-coded the script.

  
 ------------
  HOW TO USE
 ------------

 Within your mIRC, you can do these commands:
  /seen <nick|*mask*>	=  to search for saved seen entries.
  /lastspoke <nick|*mask*> 	= to see when "nick" last spoke.
  

  -Dialog-based controls-
  
  ** To bring out the dialog, 
        
       1. type /xSeen

       OR
 
       2. Right click in the channel,nicklist or status window & click the popup menu
          called "xSeen" & select "Console"

  ** Within the Console

     >> There are 2 modes in this dialog, 1) Search and 2) Settings

      -- In the Search mode, you can do search for a nick or mask for All the networks on your database or the selected network/server.
          You can either select "Seen" or "LastSpoke".

      -- In the Settings mode, the following can be seen:

      A. Servers Tab

        To Enable/Disable xSeen or for certain network/server(s) you are already connected: 

	a. On the Servers tab, select "xSeen" or "The_Network" in the drop down menu
	b. Click "Enable" to enable or "Disable" to disable the script itself in the xSeen menu

        ** Settings can be different from different networks/servers

        To Set the settings, select the Network/Server and configure.

	  ** Under xSeen
	
		- The Status option is to enable/disable the script.	
		- The Smart xSeen option will use the nick's ident in searching the database.
		- The Wildcards Option will allow wildcards if enabled.
		- The Multi-Server will allow you to see seen entries from other networks, if enabled.
		- The "Add nicks On Join" will add nicks on the channel you just joined, if enabled.
		- You can select events to be logged by xSeen (By default, all events are enabled).
		- The Duration option will give how long a nick stayed in the channel. It will log the time the script saw the nick
		   until he/she quits or parts.

	  ** Under each "Network/Server"

		- You can configure the status for each Network/Server (Enable/Disable)
		- Under "Public", you can change the Format and Target for the reply of the user's seen query.
		- Under "Private", you can Enable/Disable it if you want to allow xSeen commands on private.
		- Under "Notification", you can Enable/Disable if you want to send notifications for users seen. Format can be changed too.
		- Under "Trigger", you can change the character to be users as the trigger for xSeen commands.

      B. Channels Tab

        ** Channels can be set where you don't want the trigger & notification to work. Also where
		you don't want to save data.

      C. Data Tab

        ** Clearing Data & Simple Statistics

	Under the "ALL" menu, 

	     - Delete button is enabled. Enter the number of old days to delete in the box provided.
	     - Save button is enabled to save all entries.
	     - Statistics button is enabled. Will give out how many data entries are saved and if a network/server is selected, will also tell the oldest entry.
	     - Auto-delete options is enabled.
	     - Load button is enabled to load data from the back up file or from the data file itself. 
	      	 (Default file names are xSeen.dat & xSeen.bak, unless you have changed these names from the script)
	     - A back-up file will be created when you save the data.
	     - Reset Data would reset all data, including backup data.

   
	Under the "NETWORK" menu, 
	
	     - The Statistics, Delete & Save buttons are enabled. ( See their functions above )
             

       D. Flood Tab

	  This is where you set the trigger flood options. Set how many times the trigger can be  used 
        within a certain time. Users will be ignored for XX minutes you set if they exceed the limit.

      E. Messages Tab
	
	  This is where the outputs/messages can be edited. If you need to edit the message, 
          put a check in the checkbox. Click "Save" whenever you change something. You can also preview
          your custom output to the status or the active window. 
		
	  * You can reset the output messages by selecting "ALL" or only the current selected output.


  *** Default settings are already set when this addon is loaded.

	
 ------------------
  HOW TO UNINSTALL
 ------------------

  Simply type in any window in mIRC:

   /unload -rs xSeen.mrc

  and the script will be unloaded.

  -OR-

  Go to the Remotes Section (Alt-R) and click VIEW to select xSeen.mrc
  Then Click FILE -> UNLOAD
  Done, the script will be unloaded.

  -OR-

  Right Click on the channel,nicklist or status window & select "Unload" in the xSeen Pop up menu.
	**  (Recommended if you want to delete all xSeen files/variables)


 ---------
  CREDITS
 ---------

  - Tye (Author of Simple Seen System)

  - To the makers of Gseen & Bseen tcls - where I based the outputs

;eof