Hi All, :D This Is The New mIRC Icon
I Don't Know Who Made It But I Like
It And Hope You All Like It Too!

:D MATRIX
 NST - NetRuss Scripting Team
 http://www.netruss.org
 irc://irc.netruss.org/nst

 Thanks Everyone! Enjoy