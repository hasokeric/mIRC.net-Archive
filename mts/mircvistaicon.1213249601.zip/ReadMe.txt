mIRC Windows Vista icon
_______________________

 Filename: mirc.ico
 - mIRC icon for Windows Vista;
 Filename: mirc-xp.ico
 - mIRC icon for Windows Xp (32 bpp only);
 Filename: favicon.ico
 - mIRC icon to be used with websites;
 Filename: mirc.png
 - mIRC icon for Linux;

 NOTE: icons with PNG Compression are NOT compatible with older 
 operating systems.

 DEVELOPMENT TOOLS:     

 - ArtIcons Pro v5.xx

 How to change:

 - You can replace your shortcut icon by right-clicking the 
shortcut>Properties>Shortcut>Change Icon.
 - You can change the icon when you put mIRC on your system tray
and in mIRC window using mircustom.dll by Kamek.

 About Widows Vista PNG compression:

 A picture of a maximum size of 256 x 256 to be used as an icon, 
 in principle, is supported by XP, yet such an icon occupies 400Kb 
 of disk space, which is far more than standard 25Kb of an XP icon. 
 Aha-Soft has again found a way to cast off these shackles: 
 Articons Pro 5.0 and IconLover 4.0 uses advanced PNG compression 
 to save images without losses and supports semitransparent images 
 with 8bit alpha channel. That technology reduces the size of an icon 
 only, leaving the quality invariable. 


 Contact Information:
______________________________________________________________________

 OryNider
   www:   http://pubory.uv.ro/
   yahoo: ory_001
   msn: orynider@rdslink.ro