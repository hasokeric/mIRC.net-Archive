mIRC file icon
-----------------

Filename: mircfile.ico

An icon file I made for Script files (*.mrc), Chat Files (*.cha, *.chat) and URL:IRC Protocol. 

Its come in .png frames.

 DEVELOPMENT TOOLS:     

 - ArtIcons Pro v5.0
 - Image2Ico v2.7

How to set the icon for .mrc files step by step in Windows 98 and 98 SE:

1) Go to Start Menu -> Settings.
2) Click Folder Options.
3) Go to the file types tab and wait for your file types to load.
4) Press the New button.
5) Type your extension into the edit box, we will use MRC File but you can use anything, then press Ok.
6) Click on one of the lines in the list, then type your extension, mrc, to scroll down to it.
7) Click the Change Icon button.
8) Click the browse button then find your icon (mrcfile.ico) and press Ok, then press Close.
9) You can asociate an editor: Go back to the Folder Options -> File Types -> MRC File -> Edit 
10) Press New, the type on Action: Edit
11) Click the Browse button
12) Find the program you will use, I will use Notepad or Notepad++
13) Click Set Default 
14) Click OK and then press Close.

How to set the icon for .mrc files step by step in Windows Xp:

Note: In Windows Xp / Vista you must be an administrator to do this!
1) Open My Computer (Windows Explorer).
2) Go to the Tools menu and click Folder Options.
3) Go to the file types tab and wait for your file types to load.
4) Press the New button.
5) Type your extension into the edit box, we will use MRC File but you can use anything(Note: No period), then press Ok.
6) Click on one of the lines in the list, then type your extension, MRC, to scroll down to it.
7) Click the Advanced button.
8) Click the browse button then find your icon and press Ok, then Ok again.
9) Now click the Change button.
10) Choose "Select a program a list" then press Ok.
11) Find the program you will use, I will use 3D Editor or Notepad.
12) Check the "Always use the selected program to open this kind of file" and press Ok (Note: This icon in the list will change, but your files will still have the icon you chose).
13) Click Apply if it isn't greyed out, then press Close.


 Contact Information:
-------------------------------------------------------

 OryNider
   www:   http://pubory.uv.ro/ ex. http://pubory.lx.ro/
   yahoo: ory_001
   mail: orynider@rdslink.ro